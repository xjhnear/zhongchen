package com.melody.newprogram.user;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.melody.newprogram.ForgetPwdActivity;
import com.melody.newprogram.MainActivity;
import com.melody.newprogram.R;
import com.melody.newprogram.model.BaseResponse;
import com.melody.newprogram.util.Constant;
import com.wildma.pictureselector.PictureSelector;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

import zuo.biao.library.base.BaseActivity;
import zuo.biao.library.interfaces.OnHttpResponseListener;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.model.UserInfo;
import zuo.biao.library.ui.BottomMenuWindow;
import zuo.biao.library.ui.ToastUtils;
import zuo.biao.library.util.JSON;

public class PersonalInfoActivity extends BaseActivity implements View.OnClickListener, OnHttpResponseListener {
    private static final String[] TOPBAR_GENDER_NAMES = {"男", "女"};
    private static final int REQUEST_TO_BOTTOM_MENU = 201;

    private TextView mTvGender;
    private ImageView mImvAtor;
    private TextView mTvPhone;
    private EditText mTvName;
    private EditText mTvCompany;
    private EditText mTvAddress;
    private UserInfo userInfo;
    private int gender;
    private String filePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal);
        initView();
        initData();
    }

    @Override
    public void initView() {
        findView(R.id.ll_lianxi, this);
        findView(R.id.bt_login_submit, this);
        findView(R.id.ll_head, this);
        mTvGender = findView(R.id.tv_gender);
        mImvAtor = findView(R.id.imv_avtor);
        mTvPhone = findView(R.id.tv_phone);
        mTvName = findView(R.id.tv_name);
        mTvCompany = findView(R.id.tv_company);
        mTvAddress = findView(R.id.tv_company_address);
    }

    @Override
    public void initData() {
        userInfo = UserManager.getUserInfo();
        if (userInfo != null) {
            if ("1".equals(userInfo.getSex())) {
                mTvGender.setText("男");
            } else {
                mTvGender.setText("女");
            }
            RequestOptions mRequestOptions = RequestOptions.circleCropTransform();
            Glide.with(this).load(userInfo.getImage()).apply(mRequestOptions).into(mImvAtor);

            mTvPhone.setText(userInfo.getMobile());
            mTvName.setText(userInfo.getUsername());
            mTvCompany.setText(userInfo.getCompanyName());
            mTvAddress.setText(userInfo.getCompanyAddress());
        }


    }


    public void putData() {
        Map<String, Object> map = new HashMap<>();
        map.put("urid", UserManager.getUrid());
        userInfo.setUsername(mTvName.getText().toString());
        map.put("username", mTvName.getText().toString());
        if (!TextUtils.isEmpty(filePath)) {
            String photo = reg(BitmapFactory.decodeFile(filePath));
            if (!TextUtils.isEmpty(photo)) {
                map.put("image", photo);
            }
        }
        userInfo.setSex(gender + "");
        map.put("sex", gender);
        map.put("companyId", userInfo.getCompanyId());
        userInfo.setCompanyName(mTvCompany.getText().toString());
        map.put("companyName", userInfo.getCompanyName());
        userInfo.setCompanyAddress(mTvAddress.getText().toString());
        map.put("companyAddress", userInfo.getCompanyAddress());


        HttpManager.getInstance().post(map, Constant.USER_INFO_EDIT, Constant.USER_EDIT_CODE, this);
    }

    @Override
    public void initEvent() {

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ll_lianxi) {
            toActivity(BottomMenuWindow.createIntent(context, TOPBAR_GENDER_NAMES)
                    .putExtra(BottomMenuWindow.INTENT_TITLE, ""), REQUEST_TO_BOTTOM_MENU, false);
        } else if (v.getId() == R.id.ll_change_psd) {
            Intent intent = new Intent(this, ForgetPwdActivity.class);
            toActivity(intent.putExtra("title", "修改密码"));
        } else if (v.getId() == R.id.bt_login_submit) {
            putData();
        } else if (v.getId() == R.id.ll_head) {
            PictureSelector
                    .create(this, PictureSelector.SELECT_REQUEST_CODE)
                    .selectPicture(true, 200, 200, 1, 1);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK) {
            return;
        }

        switch (requestCode) {
            case REQUEST_TO_BOTTOM_MENU:
                int position = data.getIntExtra(BottomMenuWindow.RESULT_ITEM_ID, -1);

                if (position >= 0) {
                    mTvGender.setText(TOPBAR_GENDER_NAMES[position]);
                    gender = position + 1;
                }
                break;
            case PictureSelector.SELECT_REQUEST_CODE:
                filePath = data.getStringExtra(PictureSelector.PICTURE_PATH);
//                mIvImage.setImageBitmap(BitmapFactory.decodeFile(picturePath));

                /*如果使用 Glide 加载图片，则需要禁止 Glide 从缓存中加载，因为裁剪后保存的图片地址是相同的*/
                RequestOptions requestOptions = RequestOptions
                        .circleCropTransform()
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true);
                Glide.with(this).load(filePath).apply(requestOptions).into(mImvAtor);
                break;
        }

    }

    public String reg(Bitmap photodata) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            //将bitmap一字节流输出 Bitmap.CompressFormat.PNG 压缩格式，100：压缩率，baos：字节流
            photodata.compress(Bitmap.CompressFormat.PNG, 100, baos);
            baos.close();
            byte[] buffer = baos.toByteArray();
//            System.out.println("图片的大小："+buffer.length);

            //将图片的字节流数据加密成base64字符输出
            String photo = Base64.encodeToString(buffer, 0, buffer.length, Base64.DEFAULT);

            //photo=URLEncoder.encode(photo,"UTF-8");
//            RequestParams params = new RequestParams();
//            params.put("photo", photo);
//            params.put("name", "woshishishi");//传输的字符数据
//            String url = "http://10.0.2.2:8080/IC_Server/servlet/RegisterServlet1";
//
//
//            AsyncHttpClient client = new AsyncHttpClient();
//            client.post(url, params, new AsyncHttpResponseHandler() {
//                @Override
//                public void onSuccess(int statusCode, String content){
//                    Toast.makeText(cont, "头像上传成功!"+content, 0)
//                            .show();
//                }
//                @Override
//                public void onFailure(Throwable e, String data){
//                    Toast.makeText(cont, "头像上传失败!", 0)
//                            .show();
//                }
//            });

            return photo;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {
        if (requestCode == Constant.USER_EDIT_CODE) {
            BaseResponse baseResponse = JSON.parseObject(resultJson, BaseResponse.class);
            if (baseResponse != null) {
                ToastUtils.toast(this, baseResponse.message);
                if (baseResponse.isSuccess()) {
                    UserManager.putUserInfo(userInfo);
                    finish();
                }
            }
        }
    }

}
