package com.melody.newprogram.model;

import java.io.Serializable;
import java.util.List;

public class Order implements Serializable {
    /**
     * orid : 1
     * orderNo : 123
     * urid : 21
     * createTime : 2019-12-08 12:31:25
     * updateTime : 2019-12-08 12:31:29
     * price : 10000.00
     * payStatus : 0
     * status : 1
     * state : 1
     * productList : [{"id":"1","prid":"2","number":"1","state":"1","name":"测试产品1号","img":"http://img.52applepie.com/userdirs/product_img/2019/12/20191228191419RsaU.jpg","specs":"20","price":"10000.00","extrainfo":"[{\"title\":\"\\u53c2\\u65701\",\"content\":\"1111\"},{\"title\":\"\\u53c2\\u65702\",\"content\":\"2222\"}]"}]
     */

    private String orid;
    private String orderNo;
    private String urid;
    private String createTime;
    private String updateTime;
    private String price;
    private String payStatus;
    private String status;
    private String state;
    private List<ProductListBean> productList;



    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOrid() {
        return orid;
    }

    public void setOrid(String orid) {
        this.orid = orid;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getUrid() {
        return urid;
    }

    public void setUrid(String urid) {
        this.urid = urid;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }

    public String getStatusX() {
        return status;
    }

    public void setStatusX(String statusX) {
        this.status = statusX;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public List<ProductListBean> getProductList() {
        return productList;
    }

    public void setProductList(List<ProductListBean> productList) {
        this.productList = productList;
    }



    public static class ProductListBean implements Serializable {
        /**
         * id : 1
         * prid : 2
         * number : 1
         * state : 1
         * name : 测试产品1号
         * img : http://img.52applepie.com/userdirs/product_img/2019/12/20191228191419RsaU.jpg
         * specs : 20
         * price : 10000.00
         * extrainfo : [{"title":"\u53c2\u65701","content":"1111"},{"title":"\u53c2\u65702","content":"2222"}]
         */

        private String id;
        private String prid;
        private String number;
        private String state;
        private String name;
        private String img;
        private String specs;
        private String price;
        private String extrainfo;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPrid() {
            return prid;
        }

        public void setPrid(String prid) {
            this.prid = prid;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getImg() {
            return img;
        }

        public void setImg(String img) {
            this.img = img;
        }

        public String getSpecs() {
            return specs;
        }

        public void setSpecs(String specs) {
            this.specs = specs;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getExtrainfo() {
            return extrainfo;
        }

        public void setExtrainfo(String extrainfo) {
            this.extrainfo = extrainfo;
        }
    }
}
