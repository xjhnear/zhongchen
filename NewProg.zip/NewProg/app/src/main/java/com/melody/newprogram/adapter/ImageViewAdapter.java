package com.melody.newprogram.adapter;

import android.support.annotation.Nullable;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.melody.newprogram.R;

import java.util.List;

public class ImageViewAdapter extends BaseQuickAdapter<String, BaseViewHolder> {
    public ImageViewAdapter(@Nullable List<String> data) {
        super(R.layout.image_item, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, String item) {
        ImageView imageView = helper.getView(R.id.imv_cover);
        Glide.with(mContext).load(item).into(imageView);
    }
}
