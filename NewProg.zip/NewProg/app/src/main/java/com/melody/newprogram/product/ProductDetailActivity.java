package com.melody.newprogram.product;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.text.Html;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.melody.newprogram.R;
import com.melody.newprogram.adapter.ImageViewAdapter;
import com.melody.newprogram.model.ProductDetail;
import com.melody.newprogram.util.Constant;
import com.melody.newprogram.view.ProductCanShuView;
import com.melody.newprogram.view.ProductDetailView;
import com.melody.newprogram.view.SelectTextView;
import com.melody.newprogram.view.pagerview.PagerView;

import java.nio.channels.Selector;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zuo.biao.library.base.BaseActivity;
import zuo.biao.library.interfaces.OnHttpResponseListener;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.util.JSON;
import zuo.biao.library.util.ToolsUtil;

public class ProductDetailActivity extends BaseActivity implements OnHttpResponseListener, View.OnClickListener {
    private PagerView mPagerView;
    private ImageViewAdapter mAdapter;
    private String mPrid;
    private List<String> mPics = new ArrayList<>();
    private TextView tvPageNum;
    private ProductDetailView mPdV;
    private ProductCanShuView mPsV;
    private SelectTextView mSDes;
    private SelectTextView mCanShu;
    private TextView mTvNctice;
    private ProductDetail productDetail;
    private TextView mTvPrice;
    private TextView mTvProduce;
    private TextView mTvKuige;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_detail_activity);
        initView();
        initData();
        initEvent();
    }

    @Override
    public void initView() {
        mPagerView = findView(R.id.pageView);
        tvPageNum = findView(R.id.tv_page_num);
        mTvNctice = findView(R.id.tv_notice);
        findView(R.id.tv_lianxi, this);

        mPdV = findView(R.id.pdv);
        mPsV = findView(R.id.psv);
        mSDes = findView(R.id.sl_detail, this);
        mCanShu = findView(R.id.sl_canshu, this);
        mCanShu.setText("参数详情");
        mTvPrice = findView(R.id.tv_price);
        mTvProduce = findView(R.id.tv_produce);
        mTvKuige = findView(R.id.tv_guige);


        mSDes.setSelect(true);
        mCanShu.setSelect(false);
        mPdV.setVisibility(View.VISIBLE);
        mPsV.setVisibility(View.GONE);
    }


    private void showPics() {
        mAdapter = new ImageViewAdapter(mPics);
        mPagerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        mAdapter.bindToRecyclerView(mPagerView);
    }

    @Override
    public void initData() {
        Intent intent = getIntent();
        if (intent != null) {
            mPrid = intent.getStringExtra("prid");
        }
        Map<String, Object> map = new HashMap<>();
        map.put("urid", UserManager.getUrid());
        map.put("prid", mPrid);
        HttpManager.getInstance().post(map, Constant.PRODUCT_DETAIL, Constant.PRODUCT_DETAIL_CODE, this);

    }

    @Override
    public void initEvent() {

    }

    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {
        if (requestCode == Constant.PRODUCT_DETAIL_CODE) {
            productDetail = JSON.parseObject(resultJson, ProductDetail.class);
            if (productDetail != null && productDetail.getResult() != null) {
                mPics.add(productDetail.getResult().getImg());
                showPics();
                mPdV.setDes(productDetail.getResult().getContent());

                mTvNctice.setText(Html.fromHtml(productDetail.getResult().getRemarks()));

                mTvPrice.setText("¥" + productDetail.getResult().getPrice());

                mTvProduce.setText(productDetail.getResult().getName());

                mTvKuige.setText("类别：" + productDetail.getResult().getSpecs());

                mPsV.setData(productDetail.getResult().getExtrainfo());
            }
        }

    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.sl_detail) {
            mSDes.setSelect(true);
            mCanShu.setSelect(false);
            mPdV.setVisibility(View.VISIBLE);
            mPsV.setVisibility(View.GONE);
        } else if (v.getId() == R.id.sl_canshu) {
            mPdV.setVisibility(View.GONE);
            mPsV.setVisibility(View.VISIBLE);
            mSDes.setSelect(false);
            mCanShu.setSelect(true);
        } else if (v.getId() == R.id.tv_lianxi) {
            if (productDetail != null && productDetail.getResult() != null) {
                ToolsUtil.callPhone(this, productDetail.getHotline());
            }
        }
    }

}
