package com.melody.newprogram.view;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.FileProvider;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.melody.newprogram.R;
import com.melody.newprogram.model.UpdateResponse;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.io.File;

import io.reactivex.functions.Consumer;
import zuo.biao.library.interfaces.OnDownLoadResponseListener;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.ui.ToastUtils;
import zuo.biao.library.util.ScreenUtil;

public class UpdateDialog extends Dialog {
    private UpdateResponse mUpdateResponse;
    private TextView mTvVersion;
    private TextView mTvDes;
    private TextView mTvDone;
    private Context mContext;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg != null) {
                if (msg.what == 100) {
                    mTvDone.setText(msg.arg1 + "%");
                } else if (msg.what == 200) {
                    mTvDone.setText(msg.arg1 + "%");

                    installApkO(getContext(), (String) msg.obj);
                } else if (msg.what == 400) {
                    if (msg.obj == null) {
                        ToastUtils.toast(mContext, "更新失败，稍后重试");
                    } else {
                        ToastUtils.toast(mContext, (String) msg.obj);
                    }
                }
            }
        }
    };

    public UpdateDialog(@NonNull Context context, UpdateResponse updateResponse) {
        super(context, R.style.dialog);
        this.mContext = context;
        this.mUpdateResponse = updateResponse;
        inttView();
    }

    private void inttView() {
        setContentView(R.layout.dialog_update);

        Window dialogWindow = getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.width = ScreenUtil.dip2px(getContext(), 336); // 宽度
        lp.height = ScreenUtil.dip2px(getContext(), 448);
        //lp.width = 650;
        dialogWindow.setAttributes(lp);

        mTvVersion = findViewById(R.id.tv_version);
        mTvDes = findViewById(R.id.tv_des);

        mTvVersion.setText(mUpdateResponse.getLatest_ver());
        mTvDes.setText(mUpdateResponse.getInfo());

        mTvDone = findViewById(R.id.tv_lianxi);
        mTvDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                down();
            }
        });
    }

    private void down() {
        RxPermissions rxPermissions = new RxPermissions((FragmentActivity) mContext); // where this is an Activity or Fragment instance
        rxPermissions
                .request(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .subscribe(new Consumer<Boolean>() {
                    @Override
                    public void accept(Boolean aBoolean) throws Exception {
                        if (aBoolean) {
                            HttpManager.getInstance().downloadFile(mUpdateResponse.getLink(), new OnDownLoadResponseListener() {
                                @Override
                                public void onDownloading(boolean isSuccess, int progress, File file, String errorMsg) {
                                    if (isSuccess) {
                                        Message msg = new Message();
                                        msg.what = 100;
                                        msg.arg1 = progress;
                                        mHandler.sendMessage(msg);

                                        if (progress == 100 && file != null) {
                                            Message msg1 = new Message();
                                            msg1.what = 200;
                                            msg1.arg1 = 100;
                                            msg1.obj = file.getAbsolutePath();
                                            mHandler.sendMessage(msg1);
                                        }
                                    } else {
                                        Message msg2 = new Message();
                                        msg2.what = 400;
                                        msg2.obj = errorMsg;
                                        mHandler.sendMessage(msg2);
                                    }

                                }
                            });
                        }
                    }
                });

    }

    // 3.下载成功，开始安装,兼容8.0安装位置来源的权限
    private void installApkO(Context context, String downloadApkPath) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //是否有安装位置来源的权限
            boolean haveInstallPermission = context.getPackageManager().canRequestPackageInstalls();
            if (haveInstallPermission) {

                installApk(context, downloadApkPath);
            } else {
                ToastUtils.toast(getContext(), "安装应用需要打开安装未知来源应用权限，请去设置中开启权限");
            }
        } else {
            installApk(context, downloadApkPath);
        }
    }

    public void installApk(Context context, String downloadApk) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        File file = new File(downloadApk);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Uri apkUri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", file);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
        } else {
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Uri uri = Uri.fromFile(file);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
        }
        context.startActivity(intent);

    }
}
