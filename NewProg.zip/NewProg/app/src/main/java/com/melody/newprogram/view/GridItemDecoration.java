package com.melody.newprogram.view;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ItemDecoration;
import android.view.View;

import zuo.biao.library.util.ScreenUtil;

public class GridItemDecoration extends ItemDecoration {

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        super.getItemOffsets(outRect, view, parent, state);

        int position = parent.getChildLayoutPosition(view);
        int top = ScreenUtil.dip2px(view.getContext(), 8);
        if (position % 2 == 0) {
            outRect.set(ScreenUtil.dip2px(view.getContext(), 36), top, ScreenUtil.dip2px(view.getContext(), 8), 0);
        } else {
            outRect.set(ScreenUtil.dip2px(view.getContext(), 8), top, ScreenUtil.dip2px(view.getContext(), 36), 0);
        }
    }
}
