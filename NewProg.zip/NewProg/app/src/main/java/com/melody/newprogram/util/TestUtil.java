package com.melody.newprogram.util;

import com.melody.newprogram.model.Customer;
import com.melody.newprogram.model.Order;
import com.melody.newprogram.model.Product;

import java.util.ArrayList;
import java.util.List;

public class TestUtil {
    public static List<Product> getProductList(int page, int cacheCount) {
        List<Product> list = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Product product = new Product();
            list.add(product);
        }
        return list;
    }


    public static List<Order> getOrderList(int page, int cacheCount) {
        List<Order> list = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Order product = new Order();
            list.add(product);
        }
        return list;
    }

    public static List<Customer> getCustomerList(int page, int cacheCount) {
        List<Customer> list = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            Customer product = new Customer();
            list.add(product);
        }
        return list;
    }
}
