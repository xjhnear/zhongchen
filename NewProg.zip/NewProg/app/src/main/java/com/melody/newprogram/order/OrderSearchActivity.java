package com.melody.newprogram.order;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.melody.newprogram.R;
import com.melody.newprogram.adapter.SearchAdapter;
import com.melody.newprogram.model.EventSearch;
import com.melody.newprogram.model.Product;
import com.melody.newprogram.view.SearchView;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import zuo.biao.library.base.BaseHttpRecyclerActivity;
import zuo.biao.library.base.BaseRecyclerActivity;
import zuo.biao.library.interfaces.AdapterCallBack;
import zuo.biao.library.util.JSON;
import zuo.biao.library.util.MMkvUtil;

public class OrderSearchActivity extends BaseRecyclerActivity<String, SearchView, SearchAdapter> implements View.OnClickListener {
    private String KEY_HISTORY = "key_history";
    private EditText mEtInput;
    private TextView mTvSearch;
    private ImageView mImvDel;
    private TextView mTvClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_search);
        initView();
        initData();
        initEvent();
        getListAsync(1);
    }

    @Override
    public void initView() {
        super.initView();
        mEtInput = findViewById(R.id.et_input);
        mTvSearch = findView(R.id.tv_search, this);
        mImvDel = findView(R.id.imv_del, this);
        mTvClear = findView(R.id.tv_clear, this);
        mEtInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s != null && s.length() > 0) {
                    mImvDel.setVisibility(View.VISIBLE);
                } else {
                    mImvDel.setVisibility(View.GONE);
                }
            }
        });
    }

    @Override
    public void setList(final List<String> list) {
        setList(new AdapterCallBack<SearchAdapter>() {

            @Override
            public SearchAdapter createAdapter() {
                return new SearchAdapter(context, list);
            }

            @Override
            public void refreshAdapter() {
                adapter.refresh(list);
            }
        });
    }

    @Override
    public void initData() {

    }

    @Override
    public void getListAsync(int page) {
        String json = MMkvUtil.getIntance().getString(KEY_HISTORY);
        if (!TextUtils.isEmpty(json)) {
            setList(JSON.parseArray(json, String.class));
        }
    }

    @Override
    public void initEvent() {

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        super.onItemClick(parent, view, position, id);
        String str = adapter.getItem(position);
        doSearch(str);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tv_search) {
            String str = mEtInput.getText().toString();
            if (!TextUtils.isEmpty(str)) {
                str = str.replace(" ", "");
                if (!TextUtils.isEmpty(str)) {
                    List<String> list = JSON.parseArray(MMkvUtil.getIntance().getString(KEY_HISTORY), String.class);
                    if (list == null) {
                        list = new ArrayList<>();
                    }

                    list.add(0, str);

                    MMkvUtil.getIntance().putString(KEY_HISTORY, JSON.toJSONString(list));
                }
                doSearch(str);

            } else {
                doSearch(str);
            }
        } else if (v.getId() == R.id.imv_del) {
            mEtInput.setText(null);
        } else if (v.getId() == R.id.tv_clear) {
            MMkvUtil.getIntance().putString(KEY_HISTORY,"");
            setList(JSON.parseArray("", String.class));

        }
    }

    public void doSearch(String str) {
        EventSearch eventSearch = new EventSearch();
        eventSearch.searchKey = str;
        EventBus.getDefault().post(eventSearch);
        finish();
    }

}
