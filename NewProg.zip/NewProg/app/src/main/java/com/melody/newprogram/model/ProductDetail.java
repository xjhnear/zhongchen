package com.melody.newprogram.model;

import java.io.Serializable;
import java.util.List;

public class ProductDetail extends BaseResponse {


    /**
     * result : {"prid":"1","name":"测试产品","img":"","specs":"123","price":"1000.00","content":"123123","remarks":"132123","createTime":"2019-12-07 14:50:31","updateTime":"2019-12-07 14:50:34","state":"1","extrainfo":null}
     */

    private ResultBean result;

    public ResultBean getResult() {
        return result;
    }

    private String hotline;

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public String getHotline() {
        return hotline;
    }

    public void setHotline(String hotline) {
        this.hotline = hotline;
    }

    public static class ResultBean implements Serializable{
        /**
         * prid : 1
         * name : 测试产品
         * img :
         * specs : 123
         * price : 1000.00
         * content : 123123
         * remarks : 132123
         * createTime : 2019-12-07 14:50:31
         * updateTime : 2019-12-07 14:50:34
         * state : 1
         * extrainfo : null
         */

        private String prid;
        private String name;
        private String img;
        private String specs;
        private String price;
        private String content;
        private String remarks;
        private String createTime;
        private String updateTime;
        private String state;
        private List<ExtraInfo> extrainfo;

        public String getPrid() {
            return prid;
        }

        public void setPrid(String prid) {
            this.prid = prid;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getImg() {
            return img;
        }

        public void setImg(String img) {
            this.img = img;
        }

        public String getSpecs() {
            return specs;
        }

        public void setSpecs(String specs) {
            this.specs = specs;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getRemarks() {
            return remarks;
        }

        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        public String getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public List<ExtraInfo> getExtrainfo() {
            return extrainfo;
        }

        public void setExtrainfo(List<ExtraInfo> extrainfo) {
            this.extrainfo = extrainfo;
        }


        public static class ExtraInfo implements Serializable {
            private String title;
            private String content;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }
        }
    }
}
