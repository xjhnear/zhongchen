package com.melody.newprogram.user;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;

import com.melody.newprogram.adapter.CustomerAdapter;
import com.melody.newprogram.model.Customer;
import com.melody.newprogram.util.Constant;
import com.melody.newprogram.util.TestUtil;
import com.melody.newprogram.view.CustomerView;

import java.util.List;

import com.melody.newprogram.R;

import zuo.biao.library.base.BaseHttpRecyclerActivity;
import zuo.biao.library.interfaces.AdapterCallBack;
import zuo.biao.library.interfaces.OnBottomDragListener;
import zuo.biao.library.util.JSON;


/**
 * 使用方法：复制>粘贴>改名>改代码
 */

/**用户列表界面Activity示例
 * @author Lemon
 * @warn 复制到其它工程内使用时务必修改import R文件路径为所在应用包名
 * @use toActivity(DemoHtpRecyclerActivity.createIntent ( ...));
 */
public class MyCustomerActivity extends BaseHttpRecyclerActivity<Customer, CustomerView, CustomerAdapter> implements OnBottomDragListener, View.OnClickListener {
    //	private static final String TAG = "DemoHtpRecyclerActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_activity, this);


        //功能归类分区方法，必须调用<<<<<<<<<<
        initView();
        initData();
        initEvent();
        //功能归类分区方法，必须调用>>>>>>>>>>

        srlBaseHttpRecycler.autoRefresh();
    }


    //UI显示区(操作UI，但不存在数据获取或处理代码，也不存在事件监听代码)<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    @Override
    public void initView() {//必须调用
        super.initView();

    }

    @Override
    public void setList(final List<Customer> list) {
        setList(new AdapterCallBack<CustomerAdapter>() {

            @Override
            public CustomerAdapter createAdapter() {
                return new CustomerAdapter(context);
            }

            @Override
            public void refreshAdapter() {
                adapter.refresh(list);
            }
        });
    }


    //UI显示区(操作UI，但不存在数据获取或处理代码，也不存在事件监听代码)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    //Data数据区(存在数据获取或处理代码，但不存在事件监听代码)<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    @Override
    public void initData() {//必须调用
        super.initData();

    }

    @Override
    public void getListAsync(final int page) {
        //实际使用时用这个，需要配置服务器地址		HttpRequest.getUserList(range, page, -page, this);

        //仅测试用<<<<<<<<<<<
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                onHttpResponse(-page, page >= 5 ? null : JSON.toJSONString(TestUtil.getCustomerList(page, 10)), null);
            }
        }, 1000);
        //仅测试用>>>>>>>>>>>>
    }

    @Override
    public List<Customer> parseArray(String json) {
        return JSON.parseArray(json, Customer.class);
    }


    //Data数据区(存在数据获取或处理代码，但不存在事件监听代码)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    //Event事件区(只要存在事件监听代码就是)<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


    @Override
    public void initEvent() {//必须调用
        super.initEvent();

        findView(R.id.imv_add, this);

    }


    @Override
    public void onDragBottom(boolean rightToLeft) {
        if (rightToLeft) {

            return;
        }

        finish();
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, AddCustomerActivity.class);
        intent.putExtra(Constant.ARG_MODE, Constant.PARAM_VALUE_EDIT);
        toActivity(intent);
//        if (id > 0) {
//            toActivity(UserActivity.createIntent(context, id));
//        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.imv_add) {
            toActivity(new Intent(this, AddCustomerActivity.class));
        }
    }
}
