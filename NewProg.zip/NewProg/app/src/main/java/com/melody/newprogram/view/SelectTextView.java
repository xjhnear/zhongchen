package com.melody.newprogram.view;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.melody.newprogram.R;

public class SelectTextView extends LinearLayout {
    private TextView mTvTitle;
    private TextView mTvLine;

    public SelectTextView(Context context) {
        super(context);
        initView();
    }

    public SelectTextView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public SelectTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();

    }




    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_select_text, this);
        mTvTitle = findViewById(R.id.tv_title);
        mTvLine = findViewById(R.id.tv_line);
    }

    public void setSelect(boolean isSelected) {
        if (mTvLine != null) {
            if (isSelected) {
                mTvLine.setVisibility(View.VISIBLE);
            } else {
                mTvLine.setVisibility(View.GONE);
            }
        }
    }

    public void setText(String text) {
        if (mTvTitle != null) {
            mTvTitle.setText(text);
        }
    }
}
