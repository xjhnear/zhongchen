package com.melody.newprogram.view;

import android.app.Activity;

import com.melody.newprogram.model.Customer;
import com.melody.newprogram.R;

import zuo.biao.library.base.BaseView;

public class CustomerView extends BaseView<Customer> {
    public CustomerView(Activity context) {
        super(context, R.layout.view_customer);
    }
}
