package com.melody.newprogram.user;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import zuo.biao.library.base.BaseActivity;

import com.melody.newprogram.R;
import com.melody.newprogram.util.Constant;

public class AddCustomerActivity extends BaseActivity implements View.OnClickListener {

    private EditText mEtPhone;
    private EditText mEtName;
    private EditText mEtAddress;
    private Button mBtnSubmit;
    private ImageView mImvEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_customer);
        initView();
        initData();
        initEvent();
    }

    @Override
    public void initView() {
        mEtPhone = findView(R.id.et_phone);
        mEtName = findView(R.id.et_name);
        mEtAddress = findView(R.id.et_address);
        mBtnSubmit = findView(R.id.bt_submit);
        mImvEdit = findView(R.id.imv_edit, this);
    }

    @Override
    public void initData() {

    }

    @Override
    public void initEvent() {
        setModel(true);
        Intent intent = getIntent();
        if (intent != null) {
            if (Constant.PARAM_VALUE_EDIT == intent.getStringExtra(Constant.ARG_MODE)) {
                setModel(false);
            }

            mEtPhone.setText(intent.getStringExtra("phone"));
            mEtName.setText(intent.getStringExtra("name"));
            mEtAddress.setText(intent.getStringExtra("address"));
        }
    }

    private void setModel(boolean isEdit) {
        if (isEdit) {
            mEtPhone.setEnabled(true);
            mEtName.setEnabled(true);
            mEtAddress.setEnabled(true);
            mBtnSubmit.setVisibility(View.VISIBLE);
            mImvEdit.setVisibility(View.GONE);
        } else {
            mEtPhone.setEnabled(false);
            mEtName.setEnabled(false);
            mEtAddress.setEnabled(false);
            mBtnSubmit.setVisibility(View.GONE);
            mImvEdit.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.imv_edit) {
            setModel(true);
        }
    }
}
