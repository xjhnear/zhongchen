package com.melody.newprogram;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.melody.newprogram.model.ConfigResponse;
import com.melody.newprogram.util.Constant;

import java.util.HashMap;

import zuo.biao.library.interfaces.OnHttpResponseListener;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.util.JSON;

public class LauncherActivity extends Activity implements OnHttpResponseListener {
    private ImageView mImv;
    private TextView mTvSkip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
        initView();
        initData();
    }

    public void initView() {
        mImv = findViewById(R.id.imv);
        mTvSkip = findViewById(R.id.tv_skip);
        mTvSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jump();
            }
        });
    }

    public void initData() {
        HttpManager.getInstance().post(new HashMap<String, Object>(), Constant.URL_CONFIG, Constant.URL_CONFIG_CODE, this);
    }


    private void coutDown(long time) {
        CountDownTimer countDownTimer = new CountDownTimer(time * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                setSkipTime((int) (millisUntilFinished / 1000));
            }

            @Override
            public void onFinish() {
                jump();
            }
        };

        countDownTimer.start();
    }

    private void setSkipTime(int time) {
        if (mTvSkip != null) {
            mTvSkip.setVisibility(View.VISIBLE);
            mTvSkip.setText("跳过" + (time+1));
        }
    }

    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {
        if (requestCode == Constant.URL_CONFIG_CODE) {
            ConfigResponse response = JSON.parseObject(resultJson, ConfigResponse.class);
            if (response != null && response.isSuccess()) {
                if (response.getStartupSecond() > 0) {
                    coutDown(response.getStartupSecond());
                    Glide.with(this).load(response.getStartupPage()).into(mImv);
                    return;
                }
            }
        }
        jump();
    }

    private void jump() {
        if (TextUtils.isEmpty(UserManager.getUrid())) {
            startActivity(new Intent(this, LoginActivity.class));
        } else {
            startActivity(new Intent(this, MainActivity.class));
        }

        finish();
    }
}
