package com.melody.newprogram.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.melody.newprogram.R;

public class OrderStatusView extends RelativeLayout {
    private TextView mTvAddress;
    private TextView mTvTime;

    public OrderStatusView(Context context) {
        super(context);
        initView();
    }

    public OrderStatusView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public OrderStatusView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_order_status, this);
        mTvAddress = findViewById(R.id.tv_address1);
        mTvTime = findViewById(R.id.tv_sub1);
    }

    public void setTextDes(String des) {
        if (mTvAddress != null) {
            mTvAddress.setText(des);
        }
    }

    public void setTextTime(String time) {
        if (mTvTime != null) {
            mTvTime.setText(time);
        }
    }

}
