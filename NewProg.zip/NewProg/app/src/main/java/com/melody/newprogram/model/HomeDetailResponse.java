package com.melody.newprogram.model;

public class HomeDetailResponse extends BaseResponse {
    private Detail result;

    public Detail getResult() {
        return result;
    }

    public void setResult(Detail result) {
        this.result = result;
    }

    public static class Detail {
        private String arid;
        private String title;
        private String summary;
        private String img;
        private String content;
        private String create_at;
        private String updated_at;

        public String getArid() {
            return arid;
        }

        public void setArid(String arid) {
            this.arid = arid;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getSummary() {
            return summary;
        }

        public void setSummary(String summary) {
            this.summary = summary;
        }

        public String getImg() {
            return img;
        }

        public void setImg(String img) {
            this.img = img;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getCreate_at() {
            return create_at;
        }

        public void setCreate_at(String create_at) {
            this.create_at = create_at;
        }

        public String getUpdated_at() {
            return updated_at;
        }

        public void setUpdated_at(String updated_at) {
            this.updated_at = updated_at;
        }
    }
}
