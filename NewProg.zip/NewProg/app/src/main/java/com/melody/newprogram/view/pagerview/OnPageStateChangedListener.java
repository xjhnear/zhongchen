package com.melody.newprogram.view.pagerview;

import android.view.View;

/**
 *
 */
public interface OnPageStateChangedListener {
    /**
     * @param oldPosition old position
     * @param newPosition new position
     */
    void onPageChanged(int oldPosition, int newPosition);

    /**
     * 快速滑动后在onFling中切换到其他position,触发回调，仿抖音，在这里移除播放器
     */
    void onFlingToOtherPosition();

    /**
     * item 从window中detach
     * @param position
     */
    void onPageDetachedFromWindow(int position);


    void onPageAttachedToWindow(int position, View view);
}
