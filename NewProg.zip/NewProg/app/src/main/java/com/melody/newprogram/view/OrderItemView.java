package com.melody.newprogram.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.melody.newprogram.R;
import com.melody.newprogram.model.Order;

/**
 * orderItemView
 */
public class OrderItemView extends RelativeLayout {
    private ImageView mImvCover;
    private TextView mTvName;
    private TextView mTvGuiGe;
    private TextView mTvNum;
    private TextView mTvPrice;

    public OrderItemView(Context context) {
        super(context);
        initView();
    }

    public OrderItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public OrderItemView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_order_item, this);
        mImvCover = findViewById(R.id.imv_cover);
        mTvName = findViewById(R.id.tv_order_name);
        mTvGuiGe = findViewById(R.id.tv_order_guige);
        mTvNum = findViewById(R.id.tv_order_num);
        mTvPrice = findViewById(R.id.tv_order_price);

    }

    public void setData(Order.ProductListBean data) {
        if (data == null) {
            return;
        }
        Glide.with(getContext()).load(data.getImg()).into(mImvCover);
        mTvName.setText(data.getName());
        mTvGuiGe.setText("类别:" + data.getSpecs());
        mTvNum.setText(data.getNumber() + "件");
        mTvPrice.setText("¥" + data.getPrice());
    }
}
