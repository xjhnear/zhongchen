package com.melody.newprogram.model;

import com.melody.newprogram.util.Constant;

import java.io.Serializable;

public class BaseResponse implements Serializable{
    public String status;
    public String message;

    public boolean isSuccess() {
        return Constant.SUCCESS_CODE.equals(status);
    }
}
