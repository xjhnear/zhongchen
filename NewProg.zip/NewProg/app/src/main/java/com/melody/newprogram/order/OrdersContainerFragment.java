package com.melody.newprogram.order;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.flyco.tablayout.SlidingTabLayout;
import com.melody.newprogram.R;
import com.melody.newprogram.adapter.OrderViewPageAdapter;
import com.melody.newprogram.model.EventSearch;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import zuo.biao.library.base.BaseFragment;

/**
 * 订单
 */
public class OrdersContainerFragment extends BaseFragment implements View.OnClickListener {

    private OrderFragment orderFragment;
    private RelativeLayout mTvAll;
    private RelativeLayout mTvDaifukuan;
    private RelativeLayout mTvShengchanzhong;
    private RelativeLayout mTvYunshuzhong;
    private RelativeLayout mTvYiWanCheng;

    private RelativeLayout mRlCheckView;

    private ImageView mImvAll;
    private ImageView mImvDaifukuan;
    private ImageView mImvShengchanzhong;
    private ImageView mImvYunshuzhong;
    private ImageView mImvYiWancheng;
    private ImageView mImvDaiTiaoshi;

    private ImageView mImvSelect;

    private TextView mTvSearch;


    private int mType;

    private int tmpType;

    public static OrdersContainerFragment createInstance() {
        OrdersContainerFragment fragment = new OrdersContainerFragment();

        Bundle bundle = new Bundle();

        fragment.setArguments(bundle);
        return fragment;
    }

    //与Activity通信>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
        setContentView(R.layout.fragment_order);
        initView();
        initData();
        return view;
    }

    @Override
    public void initView() {//必须调用
        mTvAll = findView(R.id.rl_all, this);
        mTvDaifukuan = findView(R.id.rl_daifukuan, this);
        mTvShengchanzhong = findView(R.id.rl_shengchanzhong, this);
        mTvYunshuzhong = findView(R.id.rl_yunshuzhong, this);
        mTvYiWanCheng = findView(R.id.rl_yiwancheng, this);
        mRlCheckView = findView(R.id.rl_check_view, this);
        findView(R.id.rl_daitiaoshi, this);

        findView(R.id.tv_cancel, this);
        findView(R.id.tv_done, this);

        mImvAll = findView(R.id.imv_all);
        mImvDaifukuan = findView(R.id.imv_daifukuan);
        mImvShengchanzhong = findView(R.id.imv_shengchanzhong);
        mImvYunshuzhong = findView(R.id.imv_yunshuzhong);
        mImvYiWancheng = findView(R.id.imv_yiwancheng);
        mImvDaiTiaoshi = findView(R.id.imv_daitiaoshi);
        mImvSelect = findView(R.id.imv_select, this);

        mTvSearch = findView(R.id.tv_search, this);
    }

    public void initData() {//必须调用
        orderFragment = (OrderFragment) getChildFragmentManager().findFragmentById(R.id.fragment_order);
        getData();
    }

    @Override
    public void initEvent() {

    }

    private void getData() {
        if (orderFragment != null) {
            orderFragment.getDataByType(mType);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.rl_all) {
            tmpType = 0;
            showSelectImage(tmpType);
        } else if (v.getId() == R.id.rl_daifukuan) {
            tmpType = 1;
            showSelectImage(tmpType);
        } else if (v.getId() == R.id.rl_shengchanzhong) {
            tmpType = 2;
            showSelectImage(tmpType);
        } else if (v.getId() == R.id.rl_yunshuzhong) {
            tmpType = 3;
            showSelectImage(tmpType);
        } else if (v.getId() == R.id.rl_daitiaoshi) {
            tmpType = 4;
            showSelectImage(tmpType);
        } else if (v.getId() == R.id.rl_yiwancheng) {
            tmpType = 5;
            showSelectImage(tmpType);
        } else if (v.getId() == R.id.tv_cancel) {
            mRlCheckView.setVisibility(View.GONE);
            mImvSelect.setSelected(false);
        } else if (v.getId() == R.id.tv_done) {
            mType = tmpType;
            getData();
            mRlCheckView.setVisibility(View.GONE);
            mImvSelect.setSelected(false);
        } else if (v.getId() == R.id.imv_select) {
            if (mRlCheckView.getVisibility() == View.VISIBLE) {
                mImvSelect.setSelected(false);
                mRlCheckView.setVisibility(View.GONE);
            } else {
                mImvSelect.setSelected(true);
                mRlCheckView.setVisibility(View.VISIBLE);
                showSelectImage(mType);
            }
        } else if (v.getId() == R.id.tv_search) {
            toActivity(new Intent(getContext(), OrderSearchActivity.class));
        }
    }

    private void showSelectImage(int type) {
        mImvAll.setVisibility(View.GONE);
        mImvDaifukuan.setVisibility(View.GONE);
        mImvShengchanzhong.setVisibility(View.GONE);
        mImvYunshuzhong.setVisibility(View.GONE);
        mImvYiWancheng.setVisibility(View.GONE);
        mImvDaiTiaoshi.setVisibility(View.GONE);
        if (type == 0) {
            mImvAll.setVisibility(View.VISIBLE);
        } else if (type == 1) {
            mImvDaifukuan.setVisibility(View.VISIBLE);
        } else if (type == 2) {
            mImvShengchanzhong.setVisibility(View.VISIBLE);
        } else if (type == 3) {
            mImvYunshuzhong.setVisibility(View.VISIBLE);
        } else if (type == 4) {
            mImvDaiTiaoshi.setVisibility(View.VISIBLE);
        }else if (type == 5) {
            mImvYiWancheng.setVisibility(View.VISIBLE);
        }
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void doSearchEvent(EventSearch param) {
        if (param != null) {
            if (!TextUtils.isEmpty(param.searchKey)) {
                mTvSearch.setText(param.searchKey);
            } else {
                mTvSearch.setText("仪器名称/订单编号");
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }
}