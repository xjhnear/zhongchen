package com.melody.newprogram.adapter;

import android.app.Activity;
import android.view.ViewGroup;

import com.melody.newprogram.model.Customer;
import com.melody.newprogram.view.CustomerView;

import zuo.biao.library.base.BaseAdapter;

public class CustomerAdapter extends BaseAdapter<Customer, CustomerView> {
    public CustomerAdapter(Activity context) {
        super(context);
    }

    @Override
    public CustomerView createView(int viewType, ViewGroup parent) {
        return new CustomerView(context);
    }
}
