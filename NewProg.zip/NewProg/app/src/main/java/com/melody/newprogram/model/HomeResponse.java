package com.melody.newprogram.model;

import java.util.List;

public class HomeResponse extends BaseResponse{

    public List<DataBean> result;

    public static class DataBean {
        private String arid;
        private String title;
        private String img;
        private String summary;

        public String getArid() {
            return arid;
        }

        public void setArid(String arid) {
            this.arid = arid;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImg() {
            return img;
        }

        public void setImg(String img) {
            this.img = img;
        }

        public String getSummary() {
            return summary;
        }

        public void setSummary(String summary) {
            this.summary = summary;
        }
    }

}
