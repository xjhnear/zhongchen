package com.melody.newprogram.adapter;

import android.app.Activity;
import android.view.ViewGroup;

import com.melody.newprogram.model.Order;
import com.melody.newprogram.view.OrderView;

import java.util.List;

import zuo.biao.library.base.BaseAdapter;

public class OrderAdapter extends BaseAdapter<Order, OrderView> {

    public String mStatus;
    public OrderAdapter(Activity context, List<Order> data ,String status) {
        super(context);
        list = data;
        mStatus = status;
    }

    @Override
    public OrderView createView(int position, ViewGroup parent) {
        OrderView orderView = new OrderView(context, parent, mStatus);

        return orderView;
    }

    @Override
    public void bindView(int position, OrderView orderView) {
        super.bindView(position, orderView);
        if (list != null && list.size() > position) {
            orderView.bindView(list.get(position));
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

}
