package com.melody.newprogram.model;

public class EventSearch {
    public String searchKey;
}
