package com.melody.newprogram.model;

public class EventPhoneParam {
    public String phone;
}
