package com.melody.newprogram.adapter;

import android.app.Activity;
import android.view.ViewGroup;

import com.melody.newprogram.view.SearchView;

import java.util.List;

import zuo.biao.library.base.BaseAdapter;

public class SearchAdapter extends BaseAdapter<String, SearchView> {
    public SearchAdapter(Activity context, List<String> data) {
        super(context);
        list = data;
    }

    @Override
    public SearchView createView(int viewType, ViewGroup parent) {
        SearchView searchView = new SearchView(context, parent);

        return searchView;
    }

    @Override
    public void bindView(int position, SearchView searchView) {
        super.bindView(position, searchView);
        if (list != null && list.size() > position) {
            searchView.bindView(list.get(position));
        }
    }
}
