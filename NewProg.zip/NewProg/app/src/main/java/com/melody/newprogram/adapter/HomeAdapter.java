package com.melody.newprogram.adapter;

import android.support.annotation.Nullable;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.melody.newprogram.R;
import com.melody.newprogram.model.HomeResponse;

import java.util.List;

import zuo.biao.library.util.Log;

public class HomeAdapter extends BaseQuickAdapter<HomeResponse.DataBean, BaseViewHolder> {

    public HomeAdapter(@Nullable List<HomeResponse.DataBean> data) {
        super(R.layout.view_home, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, HomeResponse.DataBean item) {
        Log.e("HomeAdapter", "convert");
        ImageView imv = helper.getView(R.id.imv_bg);
        Glide.with(mContext).load(item.getImg()).into(imv);

    }
}
