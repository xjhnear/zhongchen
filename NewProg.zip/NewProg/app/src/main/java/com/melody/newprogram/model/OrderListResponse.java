package com.melody.newprogram.model;

import java.util.List;

public class OrderListResponse extends BaseResponse {

    /**
     * result : [{"orid":"1","orderNo":"123","urid":"21","createTime":"2019-12-08 12:31:25","updateTime":"2019-12-08 12:31:29","price":"10000.00","payStatus":"0","status":"1","state":"1","productList":[{"id":"1","prid":"2","number":"1","state":"1","name":"测试产品1号","img":"http://img.52applepie.com/userdirs/product_img/2019/12/20191228191419RsaU.jpg","specs":"20","price":"10000.00","extrainfo":"[{\"title\":\"\\u53c2\\u65701\",\"content\":\"1111\"},{\"title\":\"\\u53c2\\u65702\",\"content\":\"2222\"}]"}]}]
     * hotline : 4006800000
     */

    private String hotline;
    private List<Order> result;

    public List<Order> getResult() {
        return result;
    }

    public void setResult(List<Order> result) {
        this.result = result;
    }

    public String getHotline() {
        return hotline;
    }

    public void setHotline(String hotline) {
        this.hotline = hotline;
    }

}
