package com.melody.newprogram.view;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;

import com.bumptech.glide.Glide;
import com.bumptech.glide.MemoryCategory;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomViewTarget;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.ViewTarget;
import com.bumptech.glide.request.transition.Transition;
import com.melody.newprogram.R;
import com.melody.newprogram.model.EventPhoneParam;
import com.melody.newprogram.model.HomeResponse;
import com.melody.newprogram.order.OrderDetailActivity;

import org.greenrobot.eventbus.EventBus;

import zuo.biao.library.base.BaseView;
import zuo.biao.library.util.Log;
import zuo.biao.library.util.ScreenUtil;

public class HomeView extends BaseView<HomeResponse.DataBean> implements View.OnClickListener {
    private ImageView imv;
    public HomeView(Activity context, ViewGroup parent) {
        super(context, R.layout.view_home, parent);
        }

    @Override
    public View createView() {
        imv = findView(R.id.imv_bg);
        return super.createView();
    }

    @Override
    public void bindView(HomeResponse.DataBean data_) {
        super.bindView(data_);
        Log.e("HomeView", " url = " + data.getImg());
        Glide.with(context).load(data.getImg()).into(new CustomViewTarget<ImageView, Drawable>(imv) {
            @Override
            public void onLoadFailed(@Nullable Drawable errorDrawable) {

            }

            @Override
            public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                int sceenwidth = ScreenUtil.getScreenWidth(context);

                int heightW = resource.getIntrinsicWidth();
                int heightD = resource.getIntrinsicHeight();

                int viewHeigh = (sceenwidth* heightD)/heightW;

                LayoutParams lp = new LinearLayout.LayoutParams(sceenwidth, viewHeigh);
                imv.setLayoutParams(lp);
                imv.setImageDrawable(resource);

            }

            @Override
            protected void onResourceCleared(@Nullable Drawable placeholder) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tv_seller) {
            EventPhoneParam eventPhoneParam = new EventPhoneParam();
            eventPhoneParam.phone = "1321111111";
            EventBus.getDefault().post(eventPhoneParam);
        } else if (v.getId() == R.id.tv_look_detail) {
            toActivity(new Intent(context, OrderDetailActivity.class));
        }
    }

}