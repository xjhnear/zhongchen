package com.melody.newprogram.order;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.melody.newprogram.R;
import com.melody.newprogram.model.Order;
import com.melody.newprogram.model.OrderDetailResponse;
import com.melody.newprogram.view.StatusView;

import java.util.List;

import zuo.biao.library.base.BaseActivity;

public class OrderProgressActivity extends BaseActivity {
    private OrderDetailResponse.ResultBean mOrder;
    private ImageView mImvCover;
    private TextView mTvName;
    private TextView mTvGuiGe;
    private String status;
    private TextView mTvStauts;
    private LinearLayout mLlStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_progress);
        initView();
        initData();
        initEvent();
    }

    @Override
    public void initView() {
        mImvCover = findView(R.id.imv_pic);
        mTvName = findView(R.id.tv_name);
        mTvGuiGe = findView(R.id.tv_guige);
        mTvStauts = findView(R.id.tv_status);
        mLlStatus = findView(R.id.ll_status);

    }

    @Override
    public void initData() {
        Intent intent = getIntent();
        if (intent != null) {
            mOrder = (OrderDetailResponse.ResultBean) intent.getSerializableExtra("order");
            status = intent.getStringExtra("status");
        }

        if (mOrder != null) {
            List<Order.ProductListBean> productList = mOrder.getProductList();
            if (productList != null && productList.size() > 0) {
                Glide.with(context).load(productList.get(0).getImg()).into(mImvCover);
                mTvName.setText(productList.get(0).getName());
                mTvGuiGe.setText("类别：" + productList.get(0).getSpecs());
            }


            if (status.equals("1")) {
                mTvStauts.setText("新建");
            } else if (status.equals("2")) {
                mTvStauts.setText("到款");
            } else if (status.equals("3")) {
                mTvStauts.setText("开始生产");
                addStatusView(mOrder.getProduceList());
            } else if (status.equals("4")) {
                mTvStauts.setText("生产完成");
                addStatusView(mOrder.getProduceList());

            } else if (status.equals("5")) {
                mTvStauts.setText("已发货");
                addStatusView(mOrder.getExpressList());

            } else if (status.equals("6")) {
                mTvStauts.setText("已签收");
                addStatusView(mOrder.getExpressList());

            } else if (status.equals("7")) {
                mTvStauts.setText("尾款结清");
                addStatusView(mOrder.getExpressList());

            } else if (status.equals("8")) {
                mTvStauts.setText("已安排调试");
                addStatusView(mOrder.getPairList());

            } else if (status.equals("9")) {
                mTvStauts.setText("已完成");
                mLlStatus.setVisibility(View.GONE);
            }


        }


    }

    private void addStatusView(List<OrderDetailResponse.ResultBean.Produce> produces) {
        if (produces != null && produces.size() > 0) {
            for (int i = 0; i < produces.size(); i++) {
                OrderDetailResponse.ResultBean.Produce produce = produces.get(i);
                mLlStatus.removeAllViews();
                StatusView statusView = new StatusView(this);
                if (i == 0) {
                    statusView.setFirt();
                }
                if (i == produces.size() - 1) {
                    statusView.setLast();
                }
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mLlStatus.addView(statusView, lp);
            }
        }
    }

    @Override
    public void initEvent() {

    }
}
