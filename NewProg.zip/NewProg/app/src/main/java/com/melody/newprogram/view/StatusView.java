package com.melody.newprogram.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.melody.newprogram.R;

public class StatusView extends RelativeLayout {
    private View mTvFirst;
    private View mTvLast;
    private TextView mTvTime;
    private TextView mTvStatus;

    public StatusView(Context context) {
        super(context);
        initView();
    }

    public StatusView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public StatusView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_status, this);
        mTvFirst = findViewById(R.id.view_first);
        mTvLast = findViewById(R.id.view_last);
        mTvTime = findViewById(R.id.tv_time);
        mTvStatus = findViewById(R.id.tv_status);
    }

    public void setText(String time, String des) {
        mTvTime.setText(time);
        mTvStatus.setText(des);
    }

    public void setFirt() {
        if (mTvFirst != null) {
            mTvFirst.setVisibility(GONE);
        }
    }

    public void setLast() {
        if (mTvLast != null) {
            mTvLast.setVisibility(GONE);
        }
    }
}
