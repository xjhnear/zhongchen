package com.melody.newprogram.adapter;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.melody.newprogram.order.OrderFragment;

import java.util.List;

public class OrderViewPageAdapter extends FragmentPagerAdapter {
    private List<OrderFragment> mFragments;

    public OrderViewPageAdapter(FragmentManager fm, List<OrderFragment> list) {
        super(fm);
        this.mFragments = list;
    }

//    @Nullable
//    @Override
//    public CharSequence getPageTitle(int position) {
//        return super.getPageTitle(position);
//    }

    @Override
    public Fragment getItem(int i) {
        return mFragments.get(i);
    }

    @Override
    public int getCount() {
        return mFragments.size();
    }
}
