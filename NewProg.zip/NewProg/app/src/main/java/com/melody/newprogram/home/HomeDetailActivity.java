package com.melody.newprogram.home;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.melody.newprogram.R;
import com.melody.newprogram.model.HomeDetailResponse;
import com.melody.newprogram.model.ProductDetail;
import com.melody.newprogram.util.Constant;
import com.zzhoujay.richtext.ImageHolder;
import com.zzhoujay.richtext.RichText;

import java.util.HashMap;
import java.util.Map;

import zuo.biao.library.base.BaseActivity;
import zuo.biao.library.interfaces.OnHttpResponseListener;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.util.JSON;

public class HomeDetailActivity extends BaseActivity implements OnHttpResponseListener {
    private TextView mTvDetal;
    private String arid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_detail_activity);
        initView();
        initData();
        initEvent();
    }

    @Override
    public void initView() {
        mTvDetal = findView(R.id.tv_detail);
    }

    @Override
    public void initData() {
        Intent intent = getIntent();
        if (intent != null) {
            arid = intent.getStringExtra("arid");
        }
        Map<String, Object> map = new HashMap<>();
        map.put("urid", UserManager.getUrid());
        map.put("arid", arid);
        HttpManager.getInstance().post(map, Constant.URL_HOME_DETAIL, Constant.HOME_DETAIL_CODE, this);
    }

    @Override
    public void initEvent() {

    }

    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {
        if (requestCode == Constant.HOME_DETAIL_CODE) {
            HomeDetailResponse response = JSON.parseObject(resultJson, HomeDetailResponse.class);
            if (response != null && response.getResult() != null) {
                if (mTvDetal != null) {
                    RichText.initCacheDir(this);

                    RichText.from(response.getResult().getContent()).bind(this)
                            .showBorder(false)
                            .size(ImageHolder.MATCH_PARENT, ImageHolder.WRAP_CONTENT)
                            .into(mTvDetal);
                }
            }
        }
    }
}
