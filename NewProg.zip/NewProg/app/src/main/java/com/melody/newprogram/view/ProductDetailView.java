package com.melody.newprogram.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LevelListDrawable;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomViewTarget;
import com.bumptech.glide.request.transition.Transition;
import com.melody.newprogram.R;
import com.zzhoujay.richtext.ImageHolder;
import com.zzhoujay.richtext.RichText;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import zuo.biao.library.util.Log;

public class ProductDetailView extends LinearLayout {
    private TextView mTvDes;
    private LinearLayout mLlImages;

    public ProductDetailView(Context context) {
        super(context);
        initView();
    }

    public ProductDetailView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public ProductDetailView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }


    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_product, this);
        mTvDes = findViewById(R.id.tv_produce_detail);
        mLlImages = findViewById(R.id.ll_images);
    }

    public void setImages(List<String> images) {
        if (images != null) {
            for (int i = 0; i < images.size(); i++) {
                getImageView(images.get(i));
            }
        }
    }

    public void setDes(String des) {

        if (mTvDes != null) {
            RichText.initCacheDir(getContext());

            RichText.from(des).bind(this)
                    .showBorder(false)
                    .size(ImageHolder.MATCH_PARENT, ImageHolder.WRAP_CONTENT)
                    .into(mTvDes);
        }
    }

    private void getImageView(String url) {
        ImageView imageView = new ImageView(getContext());
        Glide.with(getContext()).load(url).into(imageView);
        LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        addView(imageView, lp);
    }

    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    CharSequence charSequence = (CharSequence) msg.obj;
                    if (charSequence != null) {
                        mTvDes.setText(charSequence);
//                        hotActivityContent.setMovementMethod(LinkMovementMethod.getInstance());
                    }
                    break;
                default:
                    break;
            }
        }
    };

}
