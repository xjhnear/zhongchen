package com.melody.newprogram.view;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

import com.melody.newprogram.R;
import com.melody.newprogram.model.ProductDetail;

import java.util.List;

/**
 * 产品参数
 */
public class ProductCanShuView extends LinearLayout {

    private LinearLayout mLlContent;

    public ProductCanShuView(Context context) {
        super(context);
        initView();
    }

    public ProductCanShuView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public ProductCanShuView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_product_can_shu, this);
        mLlContent = findViewById(R.id.ll_content);
    }


    public void setData(List<ProductDetail.ResultBean.ExtraInfo> data) {
        if (data != null && data.size() > 0) {
            for (int i = 0; i < data.size(); i++) {
                ProdcutCanShuItem prodcutCanShuItem = new ProdcutCanShuItem(getContext());
                prodcutCanShuItem.setText(data.get(i).getTitle(), data.get(i).getContent());
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
                mLlContent.addView(prodcutCanShuItem, lp);
            }

        }

    }
}
