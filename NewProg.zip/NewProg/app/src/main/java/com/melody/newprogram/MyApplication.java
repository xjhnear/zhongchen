package com.melody.newprogram;

import zuo.biao.library.base.BaseApplication;
import zuo.biao.library.util.MMkvUtil;

public class MyApplication extends BaseApplication {
    @Override
    public void onCreate() {
        super.onCreate();
        MMkvUtil.getIntance().init(this);
    }
}
