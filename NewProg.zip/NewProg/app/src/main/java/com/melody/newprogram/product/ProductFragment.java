package com.melody.newprogram.product;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.melody.newprogram.model.HomeResponse;
import com.melody.newprogram.model.ProduceListResponse;
import com.melody.newprogram.util.Constant;
import com.melody.newprogram.util.TestUtil;
import com.melody.newprogram.view.GridItemDecoration;
import com.melody.newprogram.view.ProductView;
import com.melody.newprogram.adapter.ProductAdapter;
import com.melody.newprogram.model.Product;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zuo.biao.library.base.BaseHttpRecyclerFragment;
import zuo.biao.library.interfaces.AdapterCallBack;
import zuo.biao.library.interfaces.CacheCallBack;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.ui.ToastUtils;
import zuo.biao.library.util.JSON;
import zuo.biao.library.util.Log;

/**
 * 产品
 */
public class ProductFragment extends BaseHttpRecyclerFragment<Product, ProductView, ProductAdapter> implements CacheCallBack<Product> {
    	private static final String TAG = "ProductFragment";

    //与Activity通信<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


    public static ProductFragment createInstance() {
        ProductFragment fragment = new ProductFragment();

        Bundle bundle = new Bundle();

        fragment.setArguments(bundle);
        return fragment;
    }

    //与Activity通信>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        if (view == null) {
            super.onCreateView(inflater, container, savedInstanceState);
            initCache(this);
            //功能归类分区方法，必须调用<<<<<<<<<<
            initView();
            initData();
            initEvent();
            //功能归类分区方法，必须调用>>>>>>>>>>
            GridItemDecoration itemDecoration = new GridItemDecoration();
            rvBaseRecycler.addItemDecoration(itemDecoration);
            rvBaseRecycler.setBackgroundColor(Color.parseColor("#F7F7F7"));
            srlBaseHttpRecycler.setEnableLoadmore(false);
            srlBaseHttpRecycler.autoRefresh();

        } else {
            ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null) {
                parent.removeView(view);
            }
        }
        return view;
    }

    @Override
    protected String getNavigatorTitle() {
        return "产品";
    }

    //UI显示区(操作UI，但不存在数据获取或处理代码，也不存在事件监听代码)<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    @Override
    public void initView() {//必须调用
        super.initView();
    }

    @Override
    public void setList(final List<Product> list) {
        setList(new AdapterCallBack<ProductAdapter>() {

            @Override
            public ProductAdapter createAdapter() {
                return new ProductAdapter(context, list);
            }

            @Override
            public void refreshAdapter() {
                adapter.refresh(list);
            }
        });
    }



    //UI显示区(操作UI，但不存在数据获取或处理代码，也不存在事件监听代码)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>










    //Data数据区(存在数据获取或处理代码，但不存在事件监听代码)<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    @Override
    public void initData() {//必须调用
        super.initData();

    }

    @Override
    public void getListAsync(final int page) {
        //实际使用时用这个，需要配置服务器地址		HttpRequest.getUserList(range, page, -page, this);
        Map<String, Object> map = new HashMap<>();
        map.put("urid", UserManager.getUrid());
        map.put("page", page);


        HttpManager.getInstance().post(map, Constant.PRODUCT_LIST, page, this);

        //仅测试用>>>>>>>>>>>>
    }



    @Override
    public List<Product> parseArray(String json) {
        return JSON.parseArray(json, Product.class);
    }


    @Override
    public Class<Product> getCacheClass() {
        return Product.class;
    }
    @Override
    public String getCacheGroup() {
        return "";
    }
    @Override
    public String getCacheId(Product data) {
        return data == null ? null : "" ;
    }
    @Override
    public int getCacheCount() {
        return 10;
    }

    @Override
    protected RecyclerView.LayoutManager getLayoutManager() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(context, 2);
        return gridLayoutManager;
    }

    //Data数据区(存在数据获取或处理代码，但不存在事件监听代码)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>








    //Event事件区(只要存在事件监听代码就是)<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


    @Override
    public void initEvent() {//必须调用
        super.initEvent();

    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Product product = adapter.getItem(position);
        Intent intent = new Intent(context, ProductDetailActivity.class);
        intent.putExtra("prid", product.getPrid());
        toActivity(intent);
    }

    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {

        ProduceListResponse response = JSON.parseObject(resultJson, ProduceListResponse.class);
        if (response != null) {
            super.onHttpResponse(-requestCode, JSON.toJSONString(response.result), e);
        } else {
            ToastUtils.toast(getContext(), response.message);
        }

    }

}
