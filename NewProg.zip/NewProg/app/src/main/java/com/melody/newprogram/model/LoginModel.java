package com.melody.newprogram.model;

public class LoginModel extends BaseResponse{
    public String urid;
}
