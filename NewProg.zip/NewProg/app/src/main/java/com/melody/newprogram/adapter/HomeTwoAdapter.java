package com.melody.newprogram.adapter;

import android.app.Activity;
import android.view.ViewGroup;

import com.melody.newprogram.model.HomeResponse;
import com.melody.newprogram.view.HomeView;
import com.melody.newprogram.view.HomeViewTwo;

import java.util.List;

import zuo.biao.library.base.BaseAdapter;
import zuo.biao.library.util.Log;

public class HomeTwoAdapter extends BaseAdapter<HomeResponse.DataBean, HomeViewTwo> {
//	private static final String TAG = "UserAdapter";

    private List<HomeResponse.DataBean> mData;

    public HomeTwoAdapter(Activity context, List<HomeResponse.DataBean> dataBeans) {
        super(context);
        this.mData = dataBeans;
    }

    @Override
    public HomeViewTwo createView(int position, ViewGroup parent) {
        Log.e("HomeView", " postion = " + position);
        return new HomeViewTwo(context, parent);
    }

    @Override
    public void bindView(int position, HomeViewTwo homeView) {
        super.bindView(position, homeView);
        Log.e("HomeView", " bindView positon = " + position);
        homeView.bindView(mData.get(position));
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

}