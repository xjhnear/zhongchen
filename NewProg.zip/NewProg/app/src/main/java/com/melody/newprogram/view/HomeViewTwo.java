package com.melody.newprogram.view;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.MultiTransformation;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.melody.newprogram.R;
import com.melody.newprogram.model.EventPhoneParam;
import com.melody.newprogram.model.HomeResponse;
import com.melody.newprogram.order.OrderDetailActivity;

import org.greenrobot.eventbus.EventBus;

import jp.wasabeef.glide.transformations.RoundedCornersTransformation;
import zuo.biao.library.base.BaseView;
import zuo.biao.library.util.Log;
import zuo.biao.library.util.ScreenUtil;

public class HomeViewTwo extends BaseView<HomeResponse.DataBean> implements View.OnClickListener {
    private ImageView imv;
    private TextView mTvTitle;
    private TextView mTvTitleSub;

    public HomeViewTwo(Activity context, ViewGroup parent) {
        super(context, R.layout.view_home_two, parent);
    }

    @Override
    public View createView() {
        imv = findView(R.id.imv_bg);
        mTvTitle = findView(R.id.tv_title);
        mTvTitleSub = findView(R.id.tv_title_sub);

        return super.createView();
    }

    @Override
    public void bindView(HomeResponse.DataBean data_) {
        super.bindView(data_);
        Log.e("HomeView", " url = " + data.getImg());
        Glide.with(context)
                .load(data.getImg())
                .apply(RequestOptions.bitmapTransform(new MultiTransformation(
                        new CenterCrop(),
                        new RoundedCornersTransformation(ScreenUtil.dip2px(context, 12), 0, RoundedCornersTransformation.CornerType.TOP))))
                .into(imv);

        mTvTitle.setText(data.getTitle());
        mTvTitleSub.setText(data.getSummary());
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tv_seller) {
            EventPhoneParam eventPhoneParam = new EventPhoneParam();
            eventPhoneParam.phone = "1321111111";
            EventBus.getDefault().post(eventPhoneParam);
        } else if (v.getId() == R.id.tv_look_detail) {
            toActivity(new Intent(context, OrderDetailActivity.class));
        }
    }
}