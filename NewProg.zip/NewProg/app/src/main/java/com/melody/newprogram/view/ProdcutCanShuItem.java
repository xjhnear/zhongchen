package com.melody.newprogram.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.melody.newprogram.R;

public class ProdcutCanShuItem extends LinearLayout{
    private TextView mTvName;
    private TextView mTvDes;
    public ProdcutCanShuItem(Context context) {
        super(context);
        initView();
    }

    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_can_shu_h, this);
        mTvName = findViewById(R.id.tv_name);
        mTvDes = findViewById(R.id.tv_des);
    }

    public void setText(String name, String des) {
        if (mTvName != null) {
            mTvName.setText(name);
        }

        if (mTvDes != null) {
            mTvDes.setText(des);
        }
    }
}
