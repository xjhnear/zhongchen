package com.melody.newprogram.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.widget.LinearLayout;

import com.melody.newprogram.R;

/**
 * @author Created by pengzhiyong on 2018/8/1.
 * 个人中心阴影
 */
public class ShadowLayerView extends LinearLayout {
    private Paint mPaint;
    private Paint bgPaint;
    /**
     * view的圆角
     */
    private int viewRadius = 20;
    /**
     * view底色
     */
    private int viewBgColor = Color.WHITE;
    /**
     * 阴影的大小
     */
    private int shadowSize = 50;
    /**
     * 阴影颜色
     */
    int shadowColor = Color.GRAY;

    private boolean isShadow = true;

    /**
     * 发光的模式默认外发光（阴影）
     * Blur.INNER(内发光)、Blur.SOLID(外发光)、Blur.NORMAL(内外发光)、Blur.OUTER(仅发光部分可见)
     */
    private BlurMaskFilter.Blur style = BlurMaskFilter.Blur.SOLID;

    public ShadowLayerView(Context context) {
        super(context);
        init(null);
    }

    public ShadowLayerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context.obtainStyledAttributes(attrs, R.styleable.ShadowLayerView));
    }

    public ShadowLayerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context.obtainStyledAttributes(attrs, R.styleable.ShadowLayerView, defStyle, 0));
    }

    private void init(TypedArray typedArray) {
        shadowColor = typedArray.getColor(R.styleable.ShadowLayerView_shadow_color, shadowColor);
        viewBgColor = typedArray.getColor(R.styleable.ShadowLayerView_view_bg_color, viewBgColor);
        shadowSize = (int) typedArray.getDimension(R.styleable.ShadowLayerView_shadow_size, shadowSize);
        viewRadius = (int) typedArray.getDimension(R.styleable.ShadowLayerView_view_radius, viewRadius);
        isShadow = typedArray.getBoolean(R.styleable.ShadowLayerView_is_shadow, isShadow);

        setWillNotDraw(false);

        //由于阴影是在view层绘制的，所以占用padding的大小
        setPadding(
                shadowSize + getPaddingLeft(),
                shadowSize + getPaddingLeft(),
                shadowSize + getPaddingLeft(),
                shadowSize + getPaddingLeft());

        mPaint = new Paint();
        mPaint.setColor(shadowColor);
//        mPaint.setAlpha((int) (255 * 0.12));//UI要百分之12的透明度
        mPaint.setAntiAlias(true);
        mPaint.setMaskFilter(new BlurMaskFilter(shadowSize, style));
        mPaint.setColor(shadowColor);

        //使用高斯模糊需关闭硬件加速
        setLayerType(LAYER_TYPE_SOFTWARE, mPaint);

        bgPaint = new Paint();
        bgPaint.setAntiAlias(true);
        bgPaint.setColor(viewBgColor);
    }

    @SuppressLint("DrawAllocation")
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (this.getVisibility() == GONE || this.getVisibility() == INVISIBLE) {
            return;
        }

        if (isShadow) {
            canvas.drawRoundRect(
                    new RectF(
                            shadowSize,
                            shadowSize,
                            getWidth() - shadowSize,
                            getHeight() - shadowSize),
                    viewRadius,
                    viewRadius,
                    mPaint);
        }

        canvas.drawRoundRect(
                new RectF(
                        shadowSize,
                        shadowSize,
                        getWidth() - shadowSize,
                        getHeight() - shadowSize),
                viewRadius,
                viewRadius,
                bgPaint);
    }
}