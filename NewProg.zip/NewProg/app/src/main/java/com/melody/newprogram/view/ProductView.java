package com.melody.newprogram.view;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.melody.newprogram.R;
import com.melody.newprogram.model.Product;

import zuo.biao.library.base.BaseView;
import zuo.biao.library.util.ScreenUtil;

public class ProductView extends BaseView<Product> {
    private ImageView mImvCover;
    private TextView mTvName;
    private TextView mTvGuige;
    private TextView mTvPrice;

    public ProductView(Activity context, ViewGroup parent) {
        super(context, R.layout.product_view, parent);
    }

    @Override
    public View createView() {
        mImvCover = findView(R.id.imv_cover);
        mTvName = findView(R.id.tv_name);
        mTvGuige = findView(R.id.tv_guige);
        mTvPrice = findView(R.id.tv_price);
//        setLayout();


        return super.createView();
    }

    private void setLayout() {
        int screenWidth = ScreenUtil.getScreenWidth(context);
        int vWidth = (screenWidth - 88) / 2;
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) mImvCover.getLayoutParams();
        lp.width = vWidth;

    }

    @Override
    public void bindView(Product data_) {
        super.bindView(data_);
        Glide.with(context).load(data.getImg()).into(mImvCover);
        mTvName.setText(data.getName());
        mTvGuige.setText("类别"+data.getSpecs());
        mTvPrice.setText("¥"+data.getPrice());
    }
}
