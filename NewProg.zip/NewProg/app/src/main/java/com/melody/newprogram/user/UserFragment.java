package com.melody.newprogram.user;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.melody.newprogram.LoginActivity;
import com.melody.newprogram.R;
import com.melody.newprogram.model.UpdateResponse;
import com.melody.newprogram.util.Constant;
import com.melody.newprogram.view.UpdateDialog;

import java.util.HashMap;
import java.util.Map;

import zuo.biao.library.base.BaseFragment;
import zuo.biao.library.interfaces.OnHttpResponseListener;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.model.UserInfo;
import zuo.biao.library.ui.AlertDialog;
import zuo.biao.library.ui.ToastUtils;
import zuo.biao.library.util.JSON;
import zuo.biao.library.util.MMkvUtil;

/**
 * 我的
 */
public class UserFragment extends BaseFragment implements View.OnClickListener, AlertDialog.OnDialogButtonClickListener, OnHttpResponseListener {


    private ImageView mImvAvtor;
    private UserInfo mUserInfo;
    private TextView mTvName;
    private TextView mTvPhone;
    private LinearLayout mLLkeHu;

    /**
     * 创建一个Fragment实例
     *
     * @return
     */
    public static UserFragment createInstance() {
        return new UserFragment();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        setContentView(R.layout.user_fragment);

        initView();
        initEvent();

        return view;
    }

    @Override
    public void initView() {//必须调用
        findView(R.id.llSettingSetting, this);
        findView(R.id.bt_login_out, this);
        findView(R.id.ll_banben, this);
        mLLkeHu = findView(R.id.ll_kehu, this);
        mImvAvtor = findView(R.id.imv_avtor);
        mTvName = findView(R.id.tv_name);
        mTvPhone = findView(R.id.tv_phone);
    }

    @Override
    public void onResume() {
        super.onResume();
        initData();
    }

    @Override
    public void initData() {//必须调用

        Map<String, Object> map = new HashMap<>();
        map.put("urid", UserManager.getUrid());
        HttpManager.getInstance().post(map, Constant.USER_INFO, Constant.USER_INFO_CODE, this);
    }

    private void checkUpdate() {
        Map<String, Object> map = new HashMap<>();
        map.put("urid", UserManager.getUrid());
        HttpManager.getInstance().post(map, Constant.CHECK_UPDATE, Constant.CHECK_UPDATE_CODE, this);
    }

    private void setData() {
        if (mUserInfo == null) {
            return;
        }
        RequestOptions mRequestOptions = RequestOptions.circleCropTransform();
        Glide.with(getContext()).load(mUserInfo.getImage()).apply(mRequestOptions).into(mImvAvtor);
        mTvName.setText(mUserInfo.getUsername());
        mTvPhone.setText(mUserInfo.getMobile());

//        if ("1".equals(mUserInfo.getType())) { //普通用户
        mLLkeHu.setVisibility(View.GONE);
//        } else if ("2".equals(mUserInfo.getType())) {//经销商用户
//            mLLkeHu.setVisibility(View.VISIBLE);
//        }
    }


    private void logout() {
        context.finish();
    }


    @Override
    public void initEvent() {//必须调用
    }


    @Override
    public void onDialogButtonClick(int requestCode, boolean isPositive) {
        if (!isPositive) {
            return;
        }

        switch (requestCode) {
            case 0:
                logout();
                break;
            default:
                break;
        }
    }


    @Override
    public void onClick(View v) {//直接调用不会显示v被点击效果

        if (v.getId() == R.id.llSettingSetting) {
            toActivity(new Intent(context, PersonalInfoActivity.class));
        } else if (v.getId() == R.id.ll_kehu) {
            toActivity(new Intent(context, MyCustomerActivity.class));
        } else if (v.getId() == R.id.bt_login_out) {
            MMkvUtil.getIntance().clearAll();
            toActivity(new Intent(getContext(), LoginActivity.class));
        } else if (v.getId() == R.id.ll_banben) {
            checkUpdate();

        }
    }


    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {
        if (requestCode == Constant.USER_INFO_CODE) {
            mUserInfo = JSON.parseObject(resultJson, UserInfo.class);
            UserManager.putUserInfo(mUserInfo);
            setData();
        } else if (requestCode == Constant.CHECK_UPDATE_CODE) {
            UpdateResponse updateResponse = JSON.parseObject(resultJson, UpdateResponse.class);
            if (updateResponse != null) {
                if (updateResponse.isSuccess()) {
                    if (updateResponse.getHasNew() == 1) {
                        UpdateDialog dialog = new UpdateDialog(getContext(), updateResponse);
                        dialog.show();
                    } else {
                        ToastUtils.toast(getContext(), "当前已是最新版本");
                    }

                } else {
                    ToastUtils.toast(getContext(), updateResponse.message);
                }
            } else {
                ToastUtils.toast(getContext(), "网络异常，稍后重新");
            }

        }
    }
}
