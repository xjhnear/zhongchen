package com.melody.newprogram.view.pagerview;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;

import com.melody.newprogram.R;


/**
 *
 */
public class PagerView extends BetterRecyclerView implements OnPageStateChangedListener, ViewTreeObserver.OnGlobalLayoutListener {

    PagerSnapHelper pagerSnapHelper;
    private int currentPosition;

    private int orientation;
    private LinearLayoutManager mLinearLayoutManager;

    public PagerView(Context context) {
        super(context);
        initView(context, null);
    }

    public PagerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context, attrs);
    }

    public PagerView(Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initView(context, attrs);
    }

    public void initView(Context context, AttributeSet attrs) {
        if (attrs != null) {
            TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.MunityPagerView);
            if (typedArray.hasValue(R.styleable.MunityPagerView_munity_orientation)) {
                orientation = typedArray.getInt(R.styleable.MunityPagerView_munity_orientation, -1);
            }
        }
        pagerSnapHelper = new PagerSnapHelper();
        pagerSnapHelper.attachToRecyclerView(this);
        pagerSnapHelper.addOnPageChangedListener(this);


        mLinearLayoutManager = new LinearLayoutManager(context, orientation, false);
        setLayoutManager(mLinearLayoutManager);
    }


    public void addOnPageChangedListener(OnPageStateChangedListener listener) {
        if (pagerSnapHelper != null) {
            pagerSnapHelper.addOnPageChangedListener(listener);
        }
    }

    @Override
    public void smoothScrollToPosition(int position) {
        super.smoothScrollToPosition(position);
    }

    public void removeOnPageChangedListener(OnPageStateChangedListener listener) {
        if (pagerSnapHelper != null) {
            pagerSnapHelper.removeOnPageChangedListener(listener);
        }
    }

    @Override
    public void scrollToPosition(int position) {
        super.scrollToPosition(position);
        if (pagerSnapHelper != null) {
            pagerSnapHelper.scrollToPosition(position);
        }

    }

    public void observeDataChange() {
        if (pagerSnapHelper != null) {
            pagerSnapHelper.observeDataChange();
        }
    }

    public void clearOnPageChangedListeners() {
        if (pagerSnapHelper != null) {
            pagerSnapHelper.clearOnPageChangedListeners();
        }
    }

    @Override
    public void onPageChanged(int oldPosition, int newPosition) {
        currentPosition = newPosition;
    }

    @Override
    public void onFlingToOtherPosition() {
//        LogUtils.d("@", "onFlingToOtherPosition");
    }

    @Override
    public void onGlobalLayout() {

    }

    @Override
    public void onPageDetachedFromWindow(int position) {

    }

    @Override
    public void onPageAttachedToWindow(int position, View view) {

    }
}
