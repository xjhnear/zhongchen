package com.melody.newprogram;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

public class ForgetPwdActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView mTvTitle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_retrieve_pwd);

        findViewById(R.id.ib_navigation_back).setOnClickListener(this);
        mTvTitle = findViewById(R.id.tv_navigation_label);


        Intent intent = getIntent();
        if (intent == null || TextUtils.isEmpty(intent.getStringExtra("title"))) {
            mTvTitle.setText("忘记秘密");
        } else {
            mTvTitle.setText(intent.getStringExtra("title"));
        }
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ib_navigation_back:
                finish();
                break;
        }
    }
}
