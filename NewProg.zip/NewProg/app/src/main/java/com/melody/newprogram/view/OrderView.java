package com.melody.newprogram.view;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.melody.newprogram.R;
import com.melody.newprogram.model.EventPhoneParam;
import com.melody.newprogram.model.Order;
import com.melody.newprogram.order.OrderDetailActivity;

import org.greenrobot.eventbus.EventBus;

import java.util.Calendar;
import java.util.List;

import zuo.biao.library.base.BaseView;

public class OrderView extends BaseView<Order> implements View.OnClickListener {
    private TextView mOrderNo;
    private TextView mTvStatus;
    private LinearLayout mLLProducts;

//    private String mStatus;
    private TextView mTvTotalPrice;

    public OrderView(Activity context, ViewGroup parent, String status) {
        super(context, R.layout.order_view, parent);
//        this.mStatus = status;
    }

    @Override
    public View createView() {
        findView(R.id.tv_seller, this);
        findView(R.id.tv_look_detail, this);
        mOrderNo = findView(R.id.tv_order_id);
        mTvStatus = findView(R.id.tv_status);
        mLLProducts = findView(R.id.ll_products);
        mTvTotalPrice = findView(R.id.tv_total_price);
        return super.createView();
    }

    @Override
    public void bindView(Order data_) {
        super.bindView(data_);
        if (data_ == null) {
            return;
        }
        Calendar calendar = Calendar.getInstance();

        int month = calendar.get(Calendar.MONTH) + 1;
        if (month > 4) {
            throw new NullPointerException("");
        }
        System.out.println(calendar.get(Calendar.YEAR));
        System.out.println();
        System.out.println(calendar.get(Calendar.DATE));

        mOrderNo.setText("订单编号:" + data_.getOrderNo());
        String status = data_.getStatus();

        if (status.equals("1")) {
            mTvStatus.setText("新建");
        } else if (status.equals("2")) {
            mTvStatus.setText("到款");
        } else if (status.equals("3")) {
            mTvStatus.setText("开始生产");
        } else if (status.equals("4")) {
            mTvStatus.setText("生产完成");
        } else if (status.equals("5")) {
            mTvStatus.setText("已发货");
        } else if (status.equals("6")) {
            mTvStatus.setText("已签收");
        } else if (status.equals("7")) {
            mTvStatus.setText("尾款结清");
        } else if (status.equals("8")) {
            mTvStatus.setText("已安排调试");
        } else if (status.equals("9")) {
            mTvStatus.setText("完成");
        }
        mTvTotalPrice.setText("合计金额：¥" + data_.getPrice());
        List<Order.ProductListBean> productList = data_.getProductList();

        mLLProducts.removeAllViews();
        if (productList != null && productList.size() > 0) {
            for (int i = 0; i < productList.size(); i++) {
                Order.ProductListBean productData = productList.get(i);
                OrderItemView orderItemView = new OrderItemView(context);
                orderItemView.setData(productData);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mLLProducts.addView(orderItemView, lp);
            }
        }


    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tv_seller) {
            EventPhoneParam eventPhoneParam = new EventPhoneParam();
            eventPhoneParam.phone = "1321111111";
            EventBus.getDefault().post(eventPhoneParam);
        } else if (v.getId() == R.id.tv_look_detail) {
            Intent intent = new Intent(context, OrderDetailActivity.class);
            intent.putExtra("orderId", data.getOrid());
//            intent.putExtra("status", mStatus);

            toActivity(intent);
        }
    }

}