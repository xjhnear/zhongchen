package com.melody.newprogram.home;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PagerSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.melody.newprogram.R;
import com.melody.newprogram.adapter.HomeAdapter;
import com.melody.newprogram.model.HomeResponse;
import com.melody.newprogram.util.Constant;

import java.util.HashMap;
import java.util.Map;

import zuo.biao.library.base.BaseFragment;
import zuo.biao.library.interfaces.OnHttpResponseListener;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.ui.ToastUtils;
import zuo.biao.library.util.JSON;

/**
 * 首页
 */
public class HomeFragment extends BaseFragment implements OnHttpResponseListener {
    public static HomeFragment createInstance() {
        return new HomeFragment();
    }

    private RecyclerView mRecyclerView;
    private HomeAdapter mAdapter;

    private View loadingView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //类相关初始化，必须使用<<<<<<<<<<<<<<<<
        super.onCreateView(inflater, container, savedInstanceState);
        setContentView(R.layout.home_fragment);
        //类相关初始化，必须使用>>>>>>>>>>>>>>>>

        //功能归类分区方法，必须调用<<<<<<<<<<
        initView();
        initData();
        initEvent();
        //功能归类分区方法，必须调用>>>>>>>>>>

        return view;
    }

    @Override
    public void initView() {
        mRecyclerView = view.findViewById(R.id.recyclerView);
        loadingView = view.findViewById(R.id.view_loading);

//        PagerSnapHelper snapHelper = new PagerSnapHelper();
//        snapHelper.attachToRecyclerView(mRecyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(linearLayoutManager);


//        mAdapter.bindToRecyclerView(mRecyclerView);
    }

    @Override
    public void initData() {
        Map<String, Object> map = new HashMap<>();
        map.put("urid", UserManager.getUrid());

        HttpManager.getInstance().post(map, Constant.ARTICLE_LIST, Constant.ARTICLE_LIST_CODE, this);
    }

    @Override
    public void initEvent() {

    }

    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {
        if (requestCode == Constant.ARTICLE_LIST_CODE) {
            loadingView.setVisibility(View.GONE);
            HomeResponse response = JSON.parseObject(resultJson, HomeResponse.class);
            if (response != null && response.isSuccess()) {

                if (mAdapter == null) {
                    mAdapter = new HomeAdapter(response.result);
                }
                mRecyclerView.setAdapter(mAdapter);

//                if (mAdapter != null) {
//                    mAdapter.setNewData(response.result);
//                }
            } else {
                ToastUtils.toast(getContext(), response.message);
            }

        }
    }
}
