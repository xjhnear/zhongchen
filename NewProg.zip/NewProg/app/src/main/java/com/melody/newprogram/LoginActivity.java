package com.melody.newprogram;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.melody.newprogram.model.BaseResponse;
import com.melody.newprogram.model.LoginModel;
import com.melody.newprogram.util.Constant;

import java.util.HashMap;
import java.util.Map;

import zuo.biao.library.interfaces.OnHttpResponseListener;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.ui.ToastUtils;
import zuo.biao.library.util.JSON;
import zuo.biao.library.util.Log;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher, OnHttpResponseListener {

    private String TAG = "LoginActivity";

    private ImageView mIbNavigationBack;
    private EditText mEtLoginUsername;
    private EditText mEtLoginPwd;
    private LinearLayout mLlLoginUsername;
    private ImageView mIvLoginUsernameDel;
    private Button mBtLoginSubmit;
    private LinearLayout mLlLoginPwd;
    private TextView mTvGetCode;
    private int timer = 60;
//    private ImageView mIvLoginPwdDel;
//    private TextView mTvLoginForgetPwd;


    private int mLogoHeight;
    private int mLogoWidth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initView();
    }

    //初始化视图
    private void initView() {
        //导航栏+返回按钮
        mIbNavigationBack = findViewById(R.id.ib_navigation_back);

        //username
        mLlLoginUsername = findViewById(R.id.ll_login_username);
        mEtLoginUsername = findViewById(R.id.et_login_username);
        mIvLoginUsernameDel = findViewById(R.id.iv_login_username_del);
        mTvGetCode = findViewById(R.id.bt_get_code);

        //passwd
        mLlLoginPwd = findViewById(R.id.ll_login_pwd);
        mEtLoginPwd = findViewById(R.id.et_login_pwd);
//        mIvLoginPwdDel = findViewById(R.id.iv_login_pwd_del);

        //提交、注册
        mBtLoginSubmit = findViewById(R.id.bt_login_submit);

        //忘记密码
//        mTvLoginForgetPwd = findViewById(R.id.tv_login_forget_pwd);
//        mTvLoginForgetPwd.setOnClickListener(this);

        //注册点击事件
        mIbNavigationBack.setOnClickListener(this);
        mEtLoginUsername.setOnClickListener(this);
        mIvLoginUsernameDel.setOnClickListener(this);
        mBtLoginSubmit.setOnClickListener(this);
        mEtLoginPwd.setOnClickListener(this);
        mTvGetCode.setOnClickListener(this);
//        mIvLoginPwdDel.setOnClickListener(this);

        //注册其它事件
        mEtLoginUsername.addTextChangedListener(this);
        mEtLoginPwd.addTextChangedListener(this);


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ib_navigation_back:
                //返回
                finish();
                break;
            case R.id.et_login_username:
                mEtLoginPwd.clearFocus();
                mEtLoginUsername.setFocusableInTouchMode(true);
                mEtLoginUsername.requestFocus();
                break;
            case R.id.et_login_pwd:
                mEtLoginUsername.clearFocus();
                mEtLoginPwd.setFocusableInTouchMode(true);
                mEtLoginPwd.requestFocus();
                break;
            case R.id.iv_login_username_del:
                //清空用户名
                mEtLoginUsername.setText(null);
                break;
            case R.id.iv_login_pwd_del:
                //清空密码
                mEtLoginPwd.setText(null);
                break;
            case R.id.bt_login_submit:
                //登录
                loginRequest();
                break;
            case R.id.bt_get_code:
                if (mTvGetCode.isSelected()) {
                    getCode();
                }
                break;
//            case R.id.tv_login_forget_pwd:
//                //忘记密码
//                startActivity(new Intent(this, ForgetPwdActivity.class));
//                break;
            default:
                break;
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    //用户名密码输入事件
    @Override
    public void afterTextChanged(Editable s) {
        String username = mEtLoginUsername.getText().toString().trim();
        String pwd = mEtLoginPwd.getText().toString().trim();

        if (username.length() > 0) {
            mIvLoginUsernameDel.setVisibility(View.VISIBLE);
        } else {
            mIvLoginUsernameDel.setVisibility(View.GONE);
        }
        //是否显示清除按钮
        if (username.length() == 11) {
            mTvGetCode.setSelected(true);
        } else {
            mTvGetCode.setSelected(false);
        }
        if (pwd.length() > 0 && username.length() == 11) {
            mBtLoginSubmit.setSelected(true);
        } else {
            mBtLoginSubmit.setSelected(false);
        }
    }

    //登录
    private void loginRequest() {

        Map<String, Object> map = new HashMap<>();
        map.put("mobile", mEtLoginUsername.getText().toString().trim());
        map.put("verifycode", mEtLoginPwd.getText().toString().trim());

        HttpManager.getInstance().post(map, Constant.USER_LOGIN, Constant.USER_LOGIN_CODE, this);

    }

    private void getCode() {
        Map<String, Object> map = new HashMap<>();
        map.put("mobile", mEtLoginUsername.getText().toString().trim());
        HttpManager.getInstance().post(map, Constant.SMS_VERIFY, Constant.SMS_VERIFY_CODE, this);

        CountDownTimer timerDown = new CountDownTimer(timer * 1000, 1000) {
            @Override
            public void onTick(long sin) {
                Log.e(TAG, "sin = " + sin);
                if (mTvGetCode != null) {
                    mTvGetCode.setText(sin / 1000 + "s");
                }
            }

            @Override
            public void onFinish() {
                mTvGetCode.setText("重新发送");
            }
        };
        timerDown.start();
    }


    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {
        if (LoginActivity.this.isDestroyed()) {
            return;
        }

        if (requestCode == Constant.SMS_VERIFY_CODE) {
            BaseResponse baseResponse = JSON.parseObject(resultJson, BaseResponse.class);
            if (baseResponse != null) {
                ToastUtils.toast(this, baseResponse.message);
            }
            Log.e(TAG, JSON.toJSONString(baseResponse));

        } else if (requestCode == Constant.USER_LOGIN_CODE) {
            LoginModel baseResponse = JSON.parseObject(resultJson, LoginModel.class);
            if (baseResponse != null) {
                ToastUtils.toast(this, baseResponse.message);
                //TODO 判断正确
                if (baseResponse.isSuccess()) {
                    UserManager.putUrid(baseResponse.urid);
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                }
            }
            Log.e(TAG, JSON.toJSONString(baseResponse));


        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
