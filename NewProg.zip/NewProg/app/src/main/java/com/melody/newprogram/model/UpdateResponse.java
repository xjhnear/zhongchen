package com.melody.newprogram.model;

public class UpdateResponse extends BaseResponse{
    private int hasNew;
    private String latest_ver;
    private String info;
    private String force;
    private String link;

    public int getHasNew() {
        return hasNew;
    }

    public void setHasNew(int hasNew) {
        this.hasNew = hasNew;
    }

    public String getLatest_ver() {
        return latest_ver;
    }

    public void setLatest_ver(String latest_ver) {
        this.latest_ver = latest_ver;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getForce() {
        return force;
    }

    public void setForce(String force) {
        this.force = force;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
