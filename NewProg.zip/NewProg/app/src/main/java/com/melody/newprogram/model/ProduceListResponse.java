package com.melody.newprogram.model;

import java.util.List;

public class ProduceListResponse extends BaseResponse {

    public List<Product> result;

}
