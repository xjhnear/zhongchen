package com.melody.newprogram.order;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.melody.newprogram.R;
import com.melody.newprogram.model.Order;
import com.melody.newprogram.model.OrderDetailResponse;
import com.melody.newprogram.model.OrderListResponse;
import com.melody.newprogram.util.Constant;
import com.melody.newprogram.view.OrderItemView;
import com.melody.newprogram.view.OrderStatusView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zuo.biao.library.base.BaseActivity;
import zuo.biao.library.interfaces.OnHttpResponseListener;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.util.JSON;
import zuo.biao.library.util.ToolsUtil;

public class OrderDetailActivity extends BaseActivity implements View.OnClickListener, OnHttpResponseListener {
    private OrderStatusView mOrderStatusView;

    private ImageView mImvStatus;
    private TextView mTvStauts;
    private LinearLayout mLlSeller;
    private TextView mTvPayMoney;
    private TextView mTvPayTime;
    private String orid;
    private OrderDetailResponse orderDetailResponse;
    private TextView mTvName;
    private TextView mTvAddress;
    private LinearLayout mLLProducts;
    private TextView mTvEtype;
    private TextView mTvOrderNo;
    private TextView mTvCreateTime;
    private TextView mTvPayType;
    private TextView getmTvPayMoney;
    private TextView mTvPayTime2;
    private TextView mTvFaType;
    private TextView mTvTitle;
    private TextView mTvEContent;
    private TextView mTvPrice;
    private String status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        initView();
        initData();
        initEvent();
    }

    @Override
    public void initView() {
        mOrderStatusView = findView(R.id.order_status);
        mImvStatus = findView(R.id.imv_icon);
        mTvStauts = findView(R.id.tv_status);
        mLlSeller = findView(R.id.ll_pay);
        mTvPayMoney = findView(R.id.tv_pay_money);
        mTvPayTime = findView(R.id.tv_pay_time);
        mTvName = findView(R.id.tv_address);
        mTvAddress = findView(R.id.tv_sub);
        mLLProducts = findView(R.id.ll_products);
        mTvOrderNo = findView(R.id.tv_order_no);
        mTvCreateTime = findView(R.id.tv_create_time);
        mTvPayType = findView(R.id.tv_pay_type);
        getmTvPayMoney = findView(R.id.tv_pay_money);
        mTvPayTime2 = findView(R.id.tv_pay_time);
        mTvFaType = findView(R.id.tv_e_type);
        mTvTitle = findView(R.id.tv_e_title);
        mTvEContent = findView(R.id.tv_e_content);
        mTvPrice = findView(R.id.tv_money);

        findView(R.id.tv_seller, this);
        findView(R.id.tv_lianxi_seller, this);
    }

    private void showStatus(String status) {
        if (TextUtils.isEmpty(status)) {
            return;
        }
        this.status = status;
        if (status.equals("1")) {
            mTvStauts.setText("新建");
            mImvStatus.setImageResource(R.mipmap.icon_pre_pay);
            mOrderStatusView.setVisibility(View.GONE);
            mLlSeller.setVisibility(View.VISIBLE);
            mTvPayMoney.setVisibility(View.GONE);
            mTvPayTime.setVisibility(View.GONE);
        } else if (status.equals("2")) {
            mTvStauts.setText("到款");
            mImvStatus.setImageResource(R.mipmap.icon_pre_pay);
            mOrderStatusView.setVisibility(View.GONE);
            mLlSeller.setVisibility(View.VISIBLE);
            mTvPayMoney.setVisibility(View.GONE);
            mTvPayTime.setVisibility(View.GONE);

        } else if (status.equals("3")) {
            mTvStauts.setText("开始生产");
            mImvStatus.setImageResource(R.mipmap.icon_d);
            mOrderStatusView.setVisibility(View.VISIBLE);
            mOrderStatusView.setTextDes("您的订单已经开始生产，点击查看更多");
            mLlSeller.setVisibility(View.GONE);
            mTvPayMoney.setVisibility(View.VISIBLE);
            mTvPayTime.setVisibility(View.VISIBLE);

        } else if (status.equals("4")) {
            mTvStauts.setText("生产完成");
            mImvStatus.setImageResource(R.mipmap.icon_s);
            mOrderStatusView.setVisibility(View.VISIBLE);
            mOrderStatusView.setTextDes("您的订单已经生产完成，点击查看更多");
            mLlSeller.setVisibility(View.GONE);
            mTvPayMoney.setVisibility(View.VISIBLE);
            mTvPayTime.setVisibility(View.VISIBLE);

        } else if (status.equals("5")) {
            mTvStauts.setText("已发货");
            mImvStatus.setImageResource(R.mipmap.icon_s);
            mOrderStatusView.setVisibility(View.VISIBLE);
            mOrderStatusView.setTextDes("您的订单已发货，点击查看更多");
            mLlSeller.setVisibility(View.GONE);
            mTvPayMoney.setVisibility(View.VISIBLE);
            mTvPayTime.setVisibility(View.VISIBLE);

        } else if (status.equals("6")) {
            mTvStauts.setText("已签收");
            mImvStatus.setImageResource(R.mipmap.icon_s);
            mOrderStatusView.setVisibility(View.VISIBLE);
            mOrderStatusView.setTextDes("您的订单已经已签收，点击查看更多");
            mLlSeller.setVisibility(View.GONE);
            mTvPayMoney.setVisibility(View.VISIBLE);
            mTvPayTime.setVisibility(View.VISIBLE);

        } else if (status.equals("7")) {
            mTvStauts.setText("尾款结清");
            mImvStatus.setImageResource(R.mipmap.icon_s);
            mOrderStatusView.setVisibility(View.VISIBLE);
            mOrderStatusView.setTextDes("您的订单尾款已结清，点击查看更多");
            mLlSeller.setVisibility(View.GONE);
            mTvPayMoney.setVisibility(View.VISIBLE);
            mTvPayTime.setVisibility(View.VISIBLE);

        } else if (status.equals("8")) {
            mTvStauts.setText("已安排调试");
            mImvStatus.setImageResource(R.mipmap.icon_s);
            mOrderStatusView.setVisibility(View.VISIBLE);
            mOrderStatusView.setTextDes("您的订单已安排调试，点击查看更多");
            mLlSeller.setVisibility(View.GONE);
            mTvPayMoney.setVisibility(View.VISIBLE);
            mTvPayTime.setVisibility(View.VISIBLE);

        } else if (status.equals("9")) {
            mTvStauts.setText("完成");
            mImvStatus.setImageResource(R.mipmap.icon_s);
            mOrderStatusView.setVisibility(View.VISIBLE);
            mOrderStatusView.setTextDes("您的订单已经生产完成，点击查看更多");
            mLlSeller.setVisibility(View.GONE);
            mTvPayMoney.setVisibility(View.VISIBLE);
            mTvPayTime.setVisibility(View.VISIBLE);

        }
    }


    @Override
    public void initData() {
        Intent intent = getIntent();
        if (intent != null) {
            orid = intent.getStringExtra("orderId");
        }


        Map<String, Object> map = new HashMap<>();
        map.put("urid", UserManager.getUrid());
        map.put("orid", orid);


        HttpManager.getInstance().post(map, Constant.ORDER_DETAIL, Constant.ORDER_DETAIL_CODE, this);

    }

    @Override
    public void initEvent() {
        mOrderStatusView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.order_status) {
            Intent intent = new Intent(this, OrderProgressActivity.class);
            intent.putExtra("order", orderDetailResponse.getResult());
            intent.putExtra("status", status);
            toActivity(intent);
        } else if (v.getId() == R.id.tv_seller || v.getId() == R.id.tv_lianxi_seller) {
            if (orderDetailResponse != null) {
                ToolsUtil.callPhone(this, orderDetailResponse.getHotline());

            }
        }
    }

    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {
        if (requestCode == Constant.ORDER_DETAIL_CODE) {

            orderDetailResponse = JSON.parseObject(resultJson, OrderDetailResponse.class);

            if (orderDetailResponse != null && orderDetailResponse.isSuccess()) {
                mOrderStatusView.setTextTime(orderDetailResponse.getResult().getCreateTime());
                mTvName.setText(orderDetailResponse.getResult().getName() + " " + orderDetailResponse.getResult().getTel());
                mTvAddress.setText(orderDetailResponse.getResult().getAddress());
                List<Order.ProductListBean> productList = orderDetailResponse.getResult().getProductList();

                if (productList != null && productList.size() > 0) {
                    for (int i = 0; i < productList.size(); i++) {
                        Order.ProductListBean productData = productList.get(i);
                        OrderItemView orderItemView = new OrderItemView(context);
                        orderItemView.setData(productData);
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        mLLProducts.addView(orderItemView, lp);
                    }
                }

                showStatus(orderDetailResponse.getResult().getStatus());

                mTvOrderNo.setText("订单编号：" + orderDetailResponse.getResult().getOrderNo());
                mTvCreateTime.setText("创建时间：" + orderDetailResponse.getResult().getCreateTime());
                mTvPayType.setText("支付方式：" + ("1".equals(orderDetailResponse.getResult().getPayType()) ? "线下" : "线上"));
                getmTvPayMoney.setText("付款金额：¥" + orderDetailResponse.getResult().getPrice());
                mTvPayTime.setText("付款时间：" + orderDetailResponse.getResult().getPayTime());
                mTvPayTime2.setText("付款时间：" + orderDetailResponse.getResult().getCreateTime());
                mTvPrice.setText("¥" + orderDetailResponse.getResult().getPrice());

                OrderDetailResponse.ResultBean.Receipt receipt = orderDetailResponse.getResult().getReceipt();
                if (receipt != null) {
                    mTvFaType.setText("发票类型：" + receipt.getType());
                    mTvTitle.setText("发票抬头：" + receipt.getTitle());
                    mTvEContent.setText("发票内容：" + receipt.getContent());
                }

            }
        }
    }
}
