package com.melody.newprogram.model;

public class ConfigResponse extends BaseResponse {
    private String startupPage;
    private int startupSecond;

    public String getStartupPage() {
        return startupPage;
    }

    public void setStartupPage(String startupPage) {
        this.startupPage = startupPage;
    }

    public int getStartupSecond() {
        return startupSecond;
    }

    public void setStartupSecond(int startupSecond) {
        this.startupSecond = startupSecond;
    }
}
