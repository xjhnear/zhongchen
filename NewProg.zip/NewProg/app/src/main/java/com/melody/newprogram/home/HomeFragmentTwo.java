package com.melody.newprogram.home;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PagerSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.melody.newprogram.R;
import com.melody.newprogram.adapter.HomeTwoAdapter;
import com.melody.newprogram.model.HomeResponse;
import com.melody.newprogram.util.Constant;
import com.melody.newprogram.view.HomeItemDecortation;
import com.melody.newprogram.view.HomeView;
import com.melody.newprogram.view.HomeViewTwo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zuo.biao.library.base.BaseHttpRecyclerFragment;
import zuo.biao.library.interfaces.AdapterCallBack;
import zuo.biao.library.interfaces.CacheCallBack;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.ui.ToastUtils;
import zuo.biao.library.util.JSON;

public class HomeFragmentTwo extends BaseHttpRecyclerFragment<HomeResponse.DataBean, HomeViewTwo, HomeTwoAdapter> implements CacheCallBack<HomeResponse.DataBean> {

    public static HomeFragmentTwo createInstance() {
        HomeFragmentTwo fragment = new HomeFragmentTwo();

        Bundle bundle = new Bundle();

        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (view == null) {
            super.onCreateView(inflater, container, savedInstanceState);

            initCache(this);

            //功能归类分区方法，必须调用<<<<<<<<<<
            initView();
            initData();
            initEvent();
            //功能归类分区方法，必须调用>>>>>>>>>>

            HomeItemDecortation homeItemDecortation = new HomeItemDecortation();
            rvBaseRecycler.addItemDecoration(homeItemDecortation);
            rvBaseRecycler.setBackgroundColor(Color.parseColor("#F7F7F7"));
            srlBaseHttpRecycler.setEnableLoadmore(false);
//            srlBaseHttpRecycler.autoRefresh();
            srlBaseHttpRecycler.autoRefresh();

        } else {
            ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null) {
                parent.removeView(view);
            }
        }



        return view;
    }

    @Override
    protected String getNavigatorTitle() {
        return "首页";
    }

    @Override
    public void initView() {
        super.initView();
//        PagerSnapHelper pagerSnapHelper = new PagerSnapHelper();
//        pagerSnapHelper.attachToRecyclerView(rvBaseRecycler);
    }

//    @Override
//    protected RecyclerView.LayoutManager getLayoutManager() {
//        return new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
//    }

    @Override
    public void setList(final List<HomeResponse.DataBean> list) {
        setList(new AdapterCallBack<HomeTwoAdapter>() {

            @Override
            public HomeTwoAdapter createAdapter() {
                return new HomeTwoAdapter(context, list);
            }

            @Override
            public void refreshAdapter() {
                adapter.refresh(list);
            }
        });
    }

    @Override
    public void getListAsync(final int page) {
        Map<String, Object> map = new HashMap<>();
        map.put("urid", UserManager.getUrid());

        HttpManager.getInstance().post(map, Constant.ARTICLE_LIST, Constant.ARTICLE_LIST_CODE, this);
    }

    @Override
    public List<HomeResponse.DataBean> parseArray(String json) {
        return JSON.parseArray(json, HomeResponse.DataBean.class);
    }


    @Override
    public Class<HomeResponse.DataBean> getCacheClass() {
        return HomeResponse.DataBean.class;
    }
    @Override
    public String getCacheGroup() {
        return "";
    }
    @Override
    public String getCacheId(HomeResponse.DataBean data) {
        return data == null ? null : "" ;
    }
    @Override
    public int getCacheCount() {
        return 10;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        HomeResponse.DataBean dataBean = adapter.getItem(position);
        if (dataBean != null) {
            Intent intent = new Intent(context, HomeDetailActivity.class);
            intent.putExtra("arid", dataBean.getArid());
            startActivity(intent);
        }
    }

    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {

        if (requestCode == Constant.ARTICLE_LIST_CODE) {
//            loadingView.setVisibility(View.GONE);
            HomeResponse response = JSON.parseObject(resultJson, HomeResponse.class);
            if (response != null && response.isSuccess()) {
                onLoadSucceed(0, response.result);

            } else {
                ToastUtils.toast(getContext(), response.message);
            }

        }
    }

}