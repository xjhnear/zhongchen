package com.melody.newprogram.adapter;

import android.app.Activity;
import android.view.ViewGroup;

import com.melody.newprogram.view.ProductView;
import com.melody.newprogram.model.Product;

import java.util.List;

import zuo.biao.library.base.BaseAdapter;
import zuo.biao.library.util.Log;

public class ProductAdapter extends BaseAdapter<Product, ProductView> {
//	private static final String TAG = "UserAdapter";

    List<Product> mData;
    public ProductAdapter(Activity context, List<Product> list) {
        super(context);
        this.mData = list;
    }

    @Override
    public ProductView createView(int position, ViewGroup parent) {
        ProductView productView = new ProductView(context, parent);
        return productView;
    }

    @Override
    public void bindView(int position, ProductView productView) {
        super.bindView(position, productView);
        Log.e("ProductAdapter", "position = " + position);
        productView.bindView(mData.get(position));
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

}
