package com.melody.newprogram.view;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import zuo.biao.library.util.ScreenUtil;

public class HomeItemDecortation extends RecyclerView.ItemDecoration {

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        super.getItemOffsets(outRect, view, parent, state);

        int position = parent.getChildLayoutPosition(view);
        int top = ScreenUtil.dip2px(view.getContext(), 8);
        int leftOrRight = ScreenUtil.dip2px(view.getContext(), 15);
        if (position == 0) {
            outRect.set(leftOrRight, top, leftOrRight, 0);
        } else {
            outRect.set(leftOrRight, top, leftOrRight, top);
        }
    }
}
