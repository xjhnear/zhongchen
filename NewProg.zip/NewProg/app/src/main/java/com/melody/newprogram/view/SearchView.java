package com.melody.newprogram.view;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.melody.newprogram.R;

import zuo.biao.library.base.BaseView;

public class SearchView extends BaseView<String> {
    private TextView mTvName;

    public SearchView(Activity context, ViewGroup parent) {
        super(context, R.layout.view_search, parent);
    }

    @Override
    public View createView() {
        mTvName = findView(R.id.tv_name);
        return super.createView();
    }

    @Override
    public void bindView(String data_) {
        super.bindView(data_);
        mTvName.setText(data_);
    }

}
