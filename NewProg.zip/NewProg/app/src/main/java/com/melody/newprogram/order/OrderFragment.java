package com.melody.newprogram.order;

import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.melody.newprogram.adapter.OrderAdapter;
import com.melody.newprogram.model.BaseResponse;
import com.melody.newprogram.model.EventSearch;
import com.melody.newprogram.model.Order;
import com.melody.newprogram.model.OrderListResponse;
import com.melody.newprogram.util.Constant;
import com.melody.newprogram.util.TestUtil;
import com.melody.newprogram.view.OrderView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zuo.biao.library.base.BaseHttpRecyclerFragment;
import zuo.biao.library.interfaces.AdapterCallBack;
import zuo.biao.library.interfaces.CacheCallBack;
import zuo.biao.library.manager.HttpManager;
import zuo.biao.library.manager.UserManager;
import zuo.biao.library.ui.ToastUtils;
import zuo.biao.library.util.JSON;
import zuo.biao.library.util.Log;

public class OrderFragment extends BaseHttpRecyclerFragment<Order, OrderView, OrderAdapter> implements CacheCallBack<Order> {

    private int mType;
    private String keyWord;

    public static OrderFragment createInstance(String type, String status) {
        OrderFragment fragment = new OrderFragment();

        Bundle bundle = new Bundle();
        bundle.putString("type", type);
        bundle.putString("status", status);

        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (view == null) {
            super.onCreateView(inflater, container, savedInstanceState);

            initCache(this);

            //功能归类分区方法，必须调用<<<<<<<<<<
            initView();
            initData();
            initEvent();
            //功能归类分区方法，必须调用>>>>>>>>>>
            srlBaseHttpRecycler.setEnableLoadmore(false);
            if (!EventBus.getDefault().isRegistered(this)) {
                EventBus.getDefault().register(this);
            }

        } else {
            ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null) {
                parent.removeView(view);
            }
        }

        return view;
    }


    @Override
    public void initView() {
        super.initView();
        mNavigatorView.setVisibility(View.GONE);
    }

    @Override
    public void initData() {
        super.initData();
//        Bundle bundle = getArguments();
//        if (bundle != null) {
//            mType = bundle.getInt("type");
//        }
    }

    @Override
    protected String getNavigatorTitle() {
        return "订单";
    }

    @Override
    public void setList(final List<Order> list) {
        setList(new AdapterCallBack<OrderAdapter>() {

            @Override
            public OrderAdapter createAdapter() {
                return new OrderAdapter(context, list, mType + "");
            }

            @Override
            public void refreshAdapter() {
                adapter.refresh(list);
            }
        });
    }

    @Override
    public void getListAsync(final int page) {

//        new Handler().postDelayed(new Runnable() {
//
//            @Override
//            public void run() {
//                onHttpResponse(-page,  JSON.toJSONString(TestUtil.getOrderList(page, getCacheCount())), null);
//            }
//        }, 1000);


        Map<String, Object> map = new HashMap<>();
        map.put("urid", UserManager.getUrid());
        if (!TextUtils.isEmpty(keyWord)) {
            map.put("keyword", keyWord);
        }
        map.put("type", mType);


        HttpManager.getInstance().post(map, Constant.ORDER_LIST, page, this);
    }

    public void getDataByType(int type) {
        this.mType = type;
        srlBaseHttpRecycler.autoRefresh();

    }

    @Override
    public List<Order> parseArray(String json) {
        return JSON.parseArray(json, Order.class);
    }


    @Override
    public Class<Order> getCacheClass() {
        return Order.class;
    }

    @Override
    public String getCacheGroup() {
        return "";
    }

    @Override
    public String getCacheId(Order data) {
        return data == null ? null : "";
    }

    @Override
    public int getCacheCount() {
        return 10;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onHttpResponse(int requestCode, String resultJson, Exception e) {

        OrderListResponse response = JSON.parseObject(resultJson, OrderListResponse.class);
        if (response != null) {
            Log.e("ddd", response.message);
            super.onHttpResponse(-requestCode, JSON.toJSONString(response.getResult()), e);
        } else {
//            ToastUtils.toast(getContext(), response.message);
        }

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void doSearchEvent(EventSearch param) {
        if (param != null) {
            keyWord = param.searchKey;
            srlBaseHttpRecycler.autoRefresh();
        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }
}
