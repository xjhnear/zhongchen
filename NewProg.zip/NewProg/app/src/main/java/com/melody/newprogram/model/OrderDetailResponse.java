package com.melody.newprogram.model;

import java.io.Serializable;
import java.util.List;

public class OrderDetailResponse extends BaseResponse {

    /**
     * result : {"orid":"1","orderNo":"123","urid":"21","name":"123","tel":"123","address":null,"createTime":"2019-12-08 12:31:25","updateTime":"2019-12-08 12:31:29","price":"10000.00","payStatus":"0","status":"1","state":"1","payType":"1","productList":[{"id":"1","prid":"2","number":"1","state":"1","name":"小米智能平板液晶屏电视","img":"http://img.52applepie.com/userdirs/product_img/2019/12/20191229154859sJgh.jpg","specs":"4C55英寸","price":"1799.00","extrainfo":"[{\"title\":\"\\u54c1\\u724c\\u540d\\u79f0\",\"content\":\"Xiaomi\\/\\u5c0f\\u7c73\"},{\"title\":\"\\u8bc1\\u4e66\\u7f16\\u53f7\",\"content\":\"2017010808942741\"},{\"title\":\"\\u8bc1\\u4e66\\u72b6\\u6001\",\"content\":\"\\u6709\\u6548\"},{\"title\":\"3C\\u4ea7\\u54c1\\u578b\\u53f7\",\"content\":\"L55M5-AZ:220V~50\\/60H\"},{\"title\":\"\\u5206\\u8fa8\\u7387\",\"content\":\"4K\\u7535\\u89c6\"},{\"title\":\"\\u80fd\\u6548\\u7b49\\u7ea7\",\"content\":\"\\u4e09\\u7ea7\"}]"}],"pairList":[]}
     * hotline : 4006800000
     */

    private ResultBean result;
    private String hotline;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public String getHotline() {
        return hotline;
    }

    public void setHotline(String hotline) {
        this.hotline = hotline;
    }

    public static class ResultBean implements Serializable {
        /**
         * orid : 1
         * orderNo : 123
         * urid : 21
         * name : 123
         * tel : 123
         * address : null
         * createTime : 2019-12-08 12:31:25
         * updateTime : 2019-12-08 12:31:29
         * price : 10000.00
         * payStatus : 0
         * status : 1
         * state : 1
         * payType : 1
         * productList : [{"id":"1","prid":"2","number":"1","state":"1","name":"小米智能平板液晶屏电视","img":"http://img.52applepie.com/userdirs/product_img/2019/12/20191229154859sJgh.jpg","specs":"4C55英寸","price":"1799.00","extrainfo":"[{\"title\":\"\\u54c1\\u724c\\u540d\\u79f0\",\"content\":\"Xiaomi\\/\\u5c0f\\u7c73\"},{\"title\":\"\\u8bc1\\u4e66\\u7f16\\u53f7\",\"content\":\"2017010808942741\"},{\"title\":\"\\u8bc1\\u4e66\\u72b6\\u6001\",\"content\":\"\\u6709\\u6548\"},{\"title\":\"3C\\u4ea7\\u54c1\\u578b\\u53f7\",\"content\":\"L55M5-AZ:220V~50\\/60H\"},{\"title\":\"\\u5206\\u8fa8\\u7387\",\"content\":\"4K\\u7535\\u89c6\"},{\"title\":\"\\u80fd\\u6548\\u7b49\\u7ea7\",\"content\":\"\\u4e09\\u7ea7\"}]"}]
         * pairList : []
         */

        private String orid;
        private String orderNo;
        private String urid;
        private String name;
        private String tel;
        private String address;
        private String createTime;
        private String updateTime;
        private String price;
        private String payStatus;
        private String status;
        private String state;
        private String payType;
        private List<Order.ProductListBean> productList;
        private String payTime;
        private Receipt receipt;

        private List<Produce> pairList;
        private List<Produce> produceList;
        private List<Produce> expressList;

        public List<Produce> getPairList() {
            return pairList;
        }

        public void setPairList(List<Produce> pairList) {
            this.pairList = pairList;
        }

        public List<Produce> getProduceList() {
            return produceList;
        }

        public void setProduceList(List<Produce> produceList) {
            this.produceList = produceList;
        }

        public List<Produce> getExpressList() {
            return expressList;
        }

        public void setExpressList(List<Produce> expressList) {
            this.expressList = expressList;
        }

        public String getPayTime() {
            return payTime;
        }

        public void setPayTime(String payTime) {
            this.payTime = payTime;
        }

        public Receipt getReceipt() {
            return receipt;
        }

        public void setReceipt(Receipt receipt) {
            this.receipt = receipt;
        }

        public String getOrid() {
            return orid;
        }

        public void setOrid(String orid) {
            this.orid = orid;
        }

        public String getOrderNo() {
            return orderNo;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public String getUrid() {
            return urid;
        }

        public void setUrid(String urid) {
            this.urid = urid;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getTel() {
            return tel;
        }

        public void setTel(String tel) {
            this.tel = tel;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        public String getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getPayStatus() {
            return payStatus;
        }

        public void setPayStatus(String payStatus) {
            this.payStatus = payStatus;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String statusX) {
            this.status = statusX;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getPayType() {
            return payType;
        }

        public void setPayType(String payType) {
            this.payType = payType;
        }

        public List<Order.ProductListBean> getProductList() {
            return productList;
        }

        public void setProductList(List<Order.ProductListBean> productList) {
            this.productList = productList;
        }


        public static class Produce implements Serializable {
            private String timestamp;
            private String content;

            public String getTimestamp() {
                return timestamp;
            }

            public void setTimestamp(String timestamp) {
                this.timestamp = timestamp;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }
        }

        public static class Receipt implements Serializable{
            private String type;
            private String title;
            private String content;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }
        }

    }
}
