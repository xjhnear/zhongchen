package com.melody.newprogram.util;

public class Constant {
    public static final String ARG_MODE = "model";

    public static final String PARAM_VALUE_EDIT = "edit";

    public static final String SUCCESS_CODE = "200";
    public static final int SMS_VERIFY_CODE = 900001;
    public static final int USER_LOGIN_CODE = 900002;
    public static final int ARTICLE_LIST_CODE = 900003;
    public static final int PRODUCT_LIST_CODE = 900004;
    public static final int PRODUCT_DETAIL_CODE = 900005;
    public static final int ORDER_DETAIL_CODE = 900006;
    public static final int USER_INFO_CODE = 900007;
    public static final int USER_EDIT_CODE = 900008;
    public static final int CHECK_UPDATE_CODE = 900009;
    public static final int URL_CONFIG_CODE = 900010;
    public static final int HOME_DETAIL_CODE = 900011;

    public static final String HOST = "http://zcapi.52applepie.com";

    public static final String SMS_VERIFY = HOST + "/sms/verify";

    public static final String USER_LOGIN = HOST + "/user/login";

    public static final String ARTICLE_LIST = HOST + "/article/getlist";

    public static final String PRODUCT_LIST = HOST + "/product/getlist";

    public static final String PRODUCT_DETAIL = HOST + "/product/getdetail";

    public static final String ORDER_LIST = HOST + "/order/getlist";

    public static final String ORDER_DETAIL = HOST + "/order/getdetail";

    public static final String USER_INFO = HOST + "/user/info";
    public static final String USER_INFO_EDIT = HOST + "/user/edit";

    public static final String CHECK_UPDATE = HOST + "/app/upgrade";

    public static final String URL_CONFIG = HOST + "/app/config";

    public static final String URL_HOME_DETAIL = HOST + "/article/getdetail";

}
