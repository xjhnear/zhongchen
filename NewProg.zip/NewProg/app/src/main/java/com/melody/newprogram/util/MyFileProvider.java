package com.melody.newprogram.util;

import android.support.v4.content.FileProvider;

public class MyFileProvider extends FileProvider {
}
